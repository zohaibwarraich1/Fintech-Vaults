﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Fintech_Vaults.BusinessLayer;
using Fintech_Vaults.DataLayer;
namespace Fintech_Vaults.PresentationLayer
{
    public partial class CardActivation : Form
    {
        public CardActivation()
        {
            InitializeComponent();
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            if (DBConnection.MatchPassword(txtPassword.Text))
            {
                DBConnection.UpdateCardPin(int.Parse(txtChangePin.Text));
                MessageBox.Show("Your Pin has been Changed!", "Successfull", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                CreditCardForm c = new CreditCardForm();
                this.Hide();
                c.Show();
            }
            else
            {
                MessageBox.Show("You have entered wrong password!", "Wrong Password", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPassword.Clear();
            }
        }

        private void btnAccountDetailsHomeForm_Click(object sender, EventArgs e)
        {
            AccountForm a = new AccountForm();
            this.Hide();
            a.Show();
        }

        private void btnHomeForm_Click(object sender, EventArgs e)
        {
            HomeForm h = new HomeForm();
            this.Hide();
            h.Show();
        }

        private void btnTransactionHistoryHomeForm_Click(object sender, EventArgs e)
        {
            TransactionHistory t = new TransactionHistory();
            t.Show();
            this.Hide();
        }

        private void btnChargesScheduleHomeForm_Click(object sender, EventArgs e)
        {
            Charges c = new Charges();
            this.Hide();
            c.Show();
        }

        private void btnPolicyHomeForm_Click(object sender, EventArgs e)
        {
            Policy p = new Policy();
            p.Show();
            this.Hide();
        }

        private void btnSettingsMenuHomeForm_Click(object sender, EventArgs e)
        {
            Settings s = new Settings();
            this.Hide();
            s.Show();
        }

        private void btnLogoutHomeForm_Click(object sender, EventArgs e)
        {
            LoginForm l = new LoginForm();
            l.Show();
            this.Hide();
        }

        private void btnManageCardMenuHomeForm_Click(object sender, EventArgs e)
        {
            CreditCardForm c = new CreditCardForm();
            this.Hide();
            c.Show();
        }

        private void CardActivation_Load(object sender, EventArgs e)
        {

        }
    }
}
