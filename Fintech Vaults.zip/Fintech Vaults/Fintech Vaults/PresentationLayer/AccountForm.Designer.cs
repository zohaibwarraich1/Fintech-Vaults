﻿namespace Fintech_Vaults.PresentationLayer
{
    partial class AccountForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtAccountNameAccountForm = new System.Windows.Forms.TextBox();
            this.lblAccountNameAccountForm = new System.Windows.Forms.Label();
            this.txtAccountNumberAccountForm = new System.Windows.Forms.TextBox();
            this.lblAccountNumberAccountForm = new System.Windows.Forms.Label();
            this.txtMobileNumberAccountForm = new System.Windows.Forms.TextBox();
            this.lblMobileNumberAccountForm = new System.Windows.Forms.Label();
            this.txtEmailAccountForm = new System.Windows.Forms.TextBox();
            this.lblAccountEmailAccountForm = new System.Windows.Forms.Label();
            this.txtPasswordAccountForm = new System.Windows.Forms.TextBox();
            this.lblAccountPasswordAccountForm = new System.Windows.Forms.Label();
            this.menuDepositMoney = new System.Windows.Forms.Panel();
            this.btnLogoutHomeForm = new System.Windows.Forms.Button();
            this.btnSettingsMenuHomeForm = new System.Windows.Forms.Button();
            this.btnPolicyHomeForm = new System.Windows.Forms.Button();
            this.btnChargesScheduleHomeForm = new System.Windows.Forms.Button();
            this.btnManageCardMenuHomeForm = new System.Windows.Forms.Button();
            this.btnTransactionHistoryHomeForm = new System.Windows.Forms.Button();
            this.btnHomeForm = new System.Windows.Forms.Button();
            this.btnAccountDetailsHomeForm = new System.Windows.Forms.Button();
            this.picboxBankLogo = new System.Windows.Forms.PictureBox();
            this.lblAccountOverviewAccountForm = new System.Windows.Forms.Label();
            this.btnShowPassAccountForm = new System.Windows.Forms.Button();
            this.menuDepositMoney.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picboxBankLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // txtAccountNameAccountForm
            // 
            this.txtAccountNameAccountForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccountNameAccountForm.Location = new System.Drawing.Point(396, 226);
            this.txtAccountNameAccountForm.Margin = new System.Windows.Forms.Padding(2);
            this.txtAccountNameAccountForm.Name = "txtAccountNameAccountForm";
            this.txtAccountNameAccountForm.ReadOnly = true;
            this.txtAccountNameAccountForm.Size = new System.Drawing.Size(243, 38);
            this.txtAccountNameAccountForm.TabIndex = 1;
            this.txtAccountNameAccountForm.TextChanged += new System.EventHandler(this.Name_TextChanged);
            // 
            // lblAccountNameAccountForm
            // 
            this.lblAccountNameAccountForm.AutoSize = true;
            this.lblAccountNameAccountForm.BackColor = System.Drawing.Color.Transparent;
            this.lblAccountNameAccountForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccountNameAccountForm.Location = new System.Drawing.Point(189, 226);
            this.lblAccountNameAccountForm.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAccountNameAccountForm.Name = "lblAccountNameAccountForm";
            this.lblAccountNameAccountForm.Size = new System.Drawing.Size(210, 36);
            this.lblAccountNameAccountForm.TabIndex = 0;
            this.lblAccountNameAccountForm.Text = "Account Name:";
            // 
            // txtAccountNumberAccountForm
            // 
            this.txtAccountNumberAccountForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccountNumberAccountForm.Location = new System.Drawing.Point(423, 380);
            this.txtAccountNumberAccountForm.Margin = new System.Windows.Forms.Padding(2);
            this.txtAccountNumberAccountForm.Name = "txtAccountNumberAccountForm";
            this.txtAccountNumberAccountForm.ReadOnly = true;
            this.txtAccountNumberAccountForm.Size = new System.Drawing.Size(241, 38);
            this.txtAccountNumberAccountForm.TabIndex = 1;
            // 
            // lblAccountNumberAccountForm
            // 
            this.lblAccountNumberAccountForm.AutoSize = true;
            this.lblAccountNumberAccountForm.BackColor = System.Drawing.Color.Transparent;
            this.lblAccountNumberAccountForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccountNumberAccountForm.Location = new System.Drawing.Point(189, 379);
            this.lblAccountNumberAccountForm.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAccountNumberAccountForm.Name = "lblAccountNumberAccountForm";
            this.lblAccountNumberAccountForm.Size = new System.Drawing.Size(239, 36);
            this.lblAccountNumberAccountForm.TabIndex = 0;
            this.lblAccountNumberAccountForm.Text = "Account Number:";
            // 
            // txtMobileNumberAccountForm
            // 
            this.txtMobileNumberAccountForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMobileNumberAccountForm.Location = new System.Drawing.Point(410, 305);
            this.txtMobileNumberAccountForm.Margin = new System.Windows.Forms.Padding(2);
            this.txtMobileNumberAccountForm.Name = "txtMobileNumberAccountForm";
            this.txtMobileNumberAccountForm.ReadOnly = true;
            this.txtMobileNumberAccountForm.Size = new System.Drawing.Size(227, 38);
            this.txtMobileNumberAccountForm.TabIndex = 1;
            // 
            // lblMobileNumberAccountForm
            // 
            this.lblMobileNumberAccountForm.AutoSize = true;
            this.lblMobileNumberAccountForm.BackColor = System.Drawing.Color.Transparent;
            this.lblMobileNumberAccountForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMobileNumberAccountForm.Location = new System.Drawing.Point(189, 303);
            this.lblMobileNumberAccountForm.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMobileNumberAccountForm.Name = "lblMobileNumberAccountForm";
            this.lblMobileNumberAccountForm.Size = new System.Drawing.Size(225, 36);
            this.lblMobileNumberAccountForm.TabIndex = 0;
            this.lblMobileNumberAccountForm.Text = "Mobile Number:";
            // 
            // txtEmailAccountForm
            // 
            this.txtEmailAccountForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmailAccountForm.Location = new System.Drawing.Point(766, 226);
            this.txtEmailAccountForm.Margin = new System.Windows.Forms.Padding(2);
            this.txtEmailAccountForm.Name = "txtEmailAccountForm";
            this.txtEmailAccountForm.ReadOnly = true;
            this.txtEmailAccountForm.Size = new System.Drawing.Size(245, 38);
            this.txtEmailAccountForm.TabIndex = 1;
            this.txtEmailAccountForm.TextChanged += new System.EventHandler(this.email_TextChanged);
            // 
            // lblAccountEmailAccountForm
            // 
            this.lblAccountEmailAccountForm.AutoSize = true;
            this.lblAccountEmailAccountForm.BackColor = System.Drawing.Color.Transparent;
            this.lblAccountEmailAccountForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccountEmailAccountForm.Location = new System.Drawing.Point(643, 226);
            this.lblAccountEmailAccountForm.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAccountEmailAccountForm.Name = "lblAccountEmailAccountForm";
            this.lblAccountEmailAccountForm.Size = new System.Drawing.Size(128, 36);
            this.lblAccountEmailAccountForm.TabIndex = 0;
            this.lblAccountEmailAccountForm.Text = "Email ID:";
            // 
            // txtPasswordAccountForm
            // 
            this.txtPasswordAccountForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPasswordAccountForm.Location = new System.Drawing.Point(779, 306);
            this.txtPasswordAccountForm.Margin = new System.Windows.Forms.Padding(2);
            this.txtPasswordAccountForm.Name = "txtPasswordAccountForm";
            this.txtPasswordAccountForm.ReadOnly = true;
            this.txtPasswordAccountForm.Size = new System.Drawing.Size(232, 38);
            this.txtPasswordAccountForm.TabIndex = 1;
            this.txtPasswordAccountForm.UseSystemPasswordChar = true;
            // 
            // lblAccountPasswordAccountForm
            // 
            this.lblAccountPasswordAccountForm.AutoSize = true;
            this.lblAccountPasswordAccountForm.BackColor = System.Drawing.Color.Transparent;
            this.lblAccountPasswordAccountForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccountPasswordAccountForm.Location = new System.Drawing.Point(641, 306);
            this.lblAccountPasswordAccountForm.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAccountPasswordAccountForm.Name = "lblAccountPasswordAccountForm";
            this.lblAccountPasswordAccountForm.Size = new System.Drawing.Size(145, 36);
            this.lblAccountPasswordAccountForm.TabIndex = 0;
            this.lblAccountPasswordAccountForm.Text = "Password:";
            // 
            // menuDepositMoney
            // 
            this.menuDepositMoney.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.menuDepositMoney.Controls.Add(this.btnLogoutHomeForm);
            this.menuDepositMoney.Controls.Add(this.btnSettingsMenuHomeForm);
            this.menuDepositMoney.Controls.Add(this.btnPolicyHomeForm);
            this.menuDepositMoney.Controls.Add(this.btnChargesScheduleHomeForm);
            this.menuDepositMoney.Controls.Add(this.btnManageCardMenuHomeForm);
            this.menuDepositMoney.Controls.Add(this.btnTransactionHistoryHomeForm);
            this.menuDepositMoney.Controls.Add(this.btnHomeForm);
            this.menuDepositMoney.Controls.Add(this.btnAccountDetailsHomeForm);
            this.menuDepositMoney.Controls.Add(this.picboxBankLogo);
            this.menuDepositMoney.Location = new System.Drawing.Point(-12, -22);
            this.menuDepositMoney.Margin = new System.Windows.Forms.Padding(2);
            this.menuDepositMoney.Name = "menuDepositMoney";
            this.menuDepositMoney.Size = new System.Drawing.Size(197, 732);
            this.menuDepositMoney.TabIndex = 2;
            // 
            // btnLogoutHomeForm
            // 
            this.btnLogoutHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLogoutHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_logout_30;
            this.btnLogoutHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnLogoutHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogoutHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLogoutHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogoutHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnLogoutHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnLogoutHomeForm.Location = new System.Drawing.Point(23, 558);
            this.btnLogoutHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnLogoutHomeForm.Name = "btnLogoutHomeForm";
            this.btnLogoutHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnLogoutHomeForm.Size = new System.Drawing.Size(158, 33);
            this.btnLogoutHomeForm.TabIndex = 8;
            this.btnLogoutHomeForm.Text = "Logout";
            this.btnLogoutHomeForm.UseVisualStyleBackColor = false;
            this.btnLogoutHomeForm.Click += new System.EventHandler(this.btnLogoutHomeForm_Click);
            // 
            // btnSettingsMenuHomeForm
            // 
            this.btnSettingsMenuHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnSettingsMenuHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_setting_30;
            this.btnSettingsMenuHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSettingsMenuHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSettingsMenuHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSettingsMenuHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettingsMenuHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnSettingsMenuHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnSettingsMenuHomeForm.Location = new System.Drawing.Point(23, 505);
            this.btnSettingsMenuHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnSettingsMenuHomeForm.Name = "btnSettingsMenuHomeForm";
            this.btnSettingsMenuHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnSettingsMenuHomeForm.Size = new System.Drawing.Size(158, 32);
            this.btnSettingsMenuHomeForm.TabIndex = 7;
            this.btnSettingsMenuHomeForm.Text = "Settings";
            this.btnSettingsMenuHomeForm.UseVisualStyleBackColor = false;
            this.btnSettingsMenuHomeForm.Click += new System.EventHandler(this.btnSettingsMenuHomeForm_Click);
            // 
            // btnPolicyHomeForm
            // 
            this.btnPolicyHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnPolicyHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_policy_30;
            this.btnPolicyHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnPolicyHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPolicyHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPolicyHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPolicyHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnPolicyHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnPolicyHomeForm.Location = new System.Drawing.Point(23, 451);
            this.btnPolicyHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnPolicyHomeForm.Name = "btnPolicyHomeForm";
            this.btnPolicyHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnPolicyHomeForm.Size = new System.Drawing.Size(158, 34);
            this.btnPolicyHomeForm.TabIndex = 6;
            this.btnPolicyHomeForm.Text = "Policy";
            this.btnPolicyHomeForm.UseVisualStyleBackColor = false;
            this.btnPolicyHomeForm.Click += new System.EventHandler(this.btnPolicyHomeForm_Click);
            // 
            // btnChargesScheduleHomeForm
            // 
            this.btnChargesScheduleHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnChargesScheduleHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_pay_wall_50;
            this.btnChargesScheduleHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnChargesScheduleHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChargesScheduleHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnChargesScheduleHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChargesScheduleHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnChargesScheduleHomeForm.Location = new System.Drawing.Point(23, 381);
            this.btnChargesScheduleHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnChargesScheduleHomeForm.Name = "btnChargesScheduleHomeForm";
            this.btnChargesScheduleHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnChargesScheduleHomeForm.Size = new System.Drawing.Size(158, 53);
            this.btnChargesScheduleHomeForm.TabIndex = 5;
            this.btnChargesScheduleHomeForm.Text = "Charges Schedule";
            this.btnChargesScheduleHomeForm.UseVisualStyleBackColor = false;
            this.btnChargesScheduleHomeForm.Click += new System.EventHandler(this.btnChargesScheduleHomeForm_Click);
            // 
            // btnManageCardMenuHomeForm
            // 
            this.btnManageCardMenuHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnManageCardMenuHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_card_30__1_;
            this.btnManageCardMenuHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnManageCardMenuHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnManageCardMenuHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnManageCardMenuHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManageCardMenuHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnManageCardMenuHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnManageCardMenuHomeForm.Location = new System.Drawing.Point(23, 327);
            this.btnManageCardMenuHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnManageCardMenuHomeForm.Name = "btnManageCardMenuHomeForm";
            this.btnManageCardMenuHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnManageCardMenuHomeForm.Size = new System.Drawing.Size(158, 30);
            this.btnManageCardMenuHomeForm.TabIndex = 4;
            this.btnManageCardMenuHomeForm.Text = "Manage Card";
            this.btnManageCardMenuHomeForm.UseVisualStyleBackColor = false;
            this.btnManageCardMenuHomeForm.Click += new System.EventHandler(this.btnManageCardMenuHomeForm_Click);
            // 
            // btnTransactionHistoryHomeForm
            // 
            this.btnTransactionHistoryHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnTransactionHistoryHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_transaction_501;
            this.btnTransactionHistoryHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnTransactionHistoryHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTransactionHistoryHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTransactionHistoryHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTransactionHistoryHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnTransactionHistoryHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnTransactionHistoryHomeForm.Location = new System.Drawing.Point(23, 254);
            this.btnTransactionHistoryHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnTransactionHistoryHomeForm.Name = "btnTransactionHistoryHomeForm";
            this.btnTransactionHistoryHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnTransactionHistoryHomeForm.Size = new System.Drawing.Size(158, 52);
            this.btnTransactionHistoryHomeForm.TabIndex = 3;
            this.btnTransactionHistoryHomeForm.Text = "Transaction History";
            this.btnTransactionHistoryHomeForm.UseVisualStyleBackColor = false;
            this.btnTransactionHistoryHomeForm.Click += new System.EventHandler(this.btnTransactionHistoryHomeForm_Click);
            // 
            // btnHomeForm
            // 
            this.btnHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_home_30;
            this.btnHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnHomeForm.Location = new System.Drawing.Point(23, 203);
            this.btnHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnHomeForm.Name = "btnHomeForm";
            this.btnHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnHomeForm.Size = new System.Drawing.Size(158, 31);
            this.btnHomeForm.TabIndex = 2;
            this.btnHomeForm.Text = "Home";
            this.btnHomeForm.UseVisualStyleBackColor = false;
            this.btnHomeForm.Click += new System.EventHandler(this.btnHomeForm_Click);
            // 
            // btnAccountDetailsHomeForm
            // 
            this.btnAccountDetailsHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnAccountDetailsHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_account_30;
            this.btnAccountDetailsHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnAccountDetailsHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAccountDetailsHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAccountDetailsHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAccountDetailsHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnAccountDetailsHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnAccountDetailsHomeForm.Location = new System.Drawing.Point(23, 154);
            this.btnAccountDetailsHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnAccountDetailsHomeForm.Name = "btnAccountDetailsHomeForm";
            this.btnAccountDetailsHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnAccountDetailsHomeForm.Size = new System.Drawing.Size(158, 31);
            this.btnAccountDetailsHomeForm.TabIndex = 1;
            this.btnAccountDetailsHomeForm.Text = "Account Details";
            this.btnAccountDetailsHomeForm.UseVisualStyleBackColor = false;
            this.btnAccountDetailsHomeForm.Click += new System.EventHandler(this.btnAccountDetailsHomeForm_Click);
            // 
            // picboxBankLogo
            // 
            this.picboxBankLogo.Image = global::Fintech_Vaults.Properties.Resources.attachment_62465982_removebg_preview;
            this.picboxBankLogo.Location = new System.Drawing.Point(0, 21);
            this.picboxBankLogo.Margin = new System.Windows.Forms.Padding(2);
            this.picboxBankLogo.Name = "picboxBankLogo";
            this.picboxBankLogo.Size = new System.Drawing.Size(221, 119);
            this.picboxBankLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picboxBankLogo.TabIndex = 0;
            this.picboxBankLogo.TabStop = false;
            // 
            // lblAccountOverviewAccountForm
            // 
            this.lblAccountOverviewAccountForm.AutoSize = true;
            this.lblAccountOverviewAccountForm.Font = new System.Drawing.Font("Bookman Old Style", 32.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccountOverviewAccountForm.Location = new System.Drawing.Point(374, 113);
            this.lblAccountOverviewAccountForm.Name = "lblAccountOverviewAccountForm";
            this.lblAccountOverviewAccountForm.Size = new System.Drawing.Size(428, 50);
            this.lblAccountOverviewAccountForm.TabIndex = 3;
            this.lblAccountOverviewAccountForm.Text = "Account Overview";
            // 
            // btnShowPassAccountForm
            // 
            this.btnShowPassAccountForm.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnShowPassAccountForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnShowPassAccountForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnShowPassAccountForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnShowPassAccountForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowPassAccountForm.ForeColor = System.Drawing.Color.Black;
            this.btnShowPassAccountForm.Location = new System.Drawing.Point(860, 364);
            this.btnShowPassAccountForm.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.btnShowPassAccountForm.Name = "btnShowPassAccountForm";
            this.btnShowPassAccountForm.Size = new System.Drawing.Size(93, 43);
            this.btnShowPassAccountForm.TabIndex = 43;
            this.btnShowPassAccountForm.Text = "Show";
            this.btnShowPassAccountForm.UseVisualStyleBackColor = false;
            this.btnShowPassAccountForm.Click += new System.EventHandler(this.btnShowPassAccountForm_Click);
            // 
            // AccountForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(1022, 586);
            this.Controls.Add(this.btnShowPassAccountForm);
            this.Controls.Add(this.lblAccountOverviewAccountForm);
            this.Controls.Add(this.menuDepositMoney);
            this.Controls.Add(this.txtPasswordAccountForm);
            this.Controls.Add(this.txtEmailAccountForm);
            this.Controls.Add(this.lblAccountPasswordAccountForm);
            this.Controls.Add(this.txtMobileNumberAccountForm);
            this.Controls.Add(this.lblAccountEmailAccountForm);
            this.Controls.Add(this.txtAccountNumberAccountForm);
            this.Controls.Add(this.lblMobileNumberAccountForm);
            this.Controls.Add(this.txtAccountNameAccountForm);
            this.Controls.Add(this.lblAccountNumberAccountForm);
            this.Controls.Add(this.lblAccountNameAccountForm);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "AccountForm";
            this.Text = "AccountForm";
            this.Load += new System.EventHandler(this.AccountForm_Load);
            this.menuDepositMoney.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picboxBankLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblAccountNameAccountForm;
        private System.Windows.Forms.TextBox txtAccountNameAccountForm;
        private System.Windows.Forms.Label lblAccountNumberAccountForm;
        private System.Windows.Forms.TextBox txtAccountNumberAccountForm;
        private System.Windows.Forms.Label lblMobileNumberAccountForm;
        private System.Windows.Forms.TextBox txtMobileNumberAccountForm;
        private System.Windows.Forms.Label lblAccountEmailAccountForm;
        private System.Windows.Forms.TextBox txtEmailAccountForm;
        private System.Windows.Forms.TextBox txtPasswordAccountForm;
        private System.Windows.Forms.Label lblAccountPasswordAccountForm;
        private System.Windows.Forms.Panel menuDepositMoney;
        private System.Windows.Forms.Button btnLogoutHomeForm;
        private System.Windows.Forms.Button btnSettingsMenuHomeForm;
        private System.Windows.Forms.Button btnPolicyHomeForm;
        private System.Windows.Forms.Button btnChargesScheduleHomeForm;
        private System.Windows.Forms.Button btnManageCardMenuHomeForm;
        private System.Windows.Forms.Button btnTransactionHistoryHomeForm;
        private System.Windows.Forms.Button btnHomeForm;
        private System.Windows.Forms.Button btnAccountDetailsHomeForm;
        private System.Windows.Forms.PictureBox picboxBankLogo;
        private System.Windows.Forms.Label lblAccountOverviewAccountForm;
        private System.Windows.Forms.Button btnShowPassAccountForm;
    }
}