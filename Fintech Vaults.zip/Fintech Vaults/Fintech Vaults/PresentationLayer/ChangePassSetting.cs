﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Fintech_Vaults.BusinessLayer;
using Fintech_Vaults.DataLayer;
namespace Fintech_Vaults.PresentationLayer
{
    public partial class btnChangePassCPS : Form
    {
        public btnChangePassCPS()
        {
            InitializeComponent();
        }

        private void ChangePassSetting_Load(object sender, EventArgs e)
        {

        }

        private void btnConfirmPaymentBAD_Click(object sender, EventArgs e)
        {
            string oldPass = txtOldPassCPS.Text;
            string newPass = txtNewPassCPS.Text;
            string confirmNewPass = txtConfirmNewPassCPS.Text;
            if (newPass == confirmNewPass)
            {
                if (DBConnection.OldPasswordCheckSetting(oldPass))
                {
                    DBConnection.ChangeNewPasswordSetting(newPass);
                    MessageBox.Show("Password has been Changed!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("You have entered wrong Old Password!", "Wrong Old Password", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtOldPassCPS.Clear();
                }
            }
            else
            {
                MessageBox.Show("You have entered Wrond New Pass\nOr Confirm New Pass", "Wrong Info", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNewPassCPS.Clear();
                txtConfirmNewPassCPS.Clear();
            }
        }

        private void btnLogoutHomeForm_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }

        private void btnSettingsMenuHomeForm_Click(object sender, EventArgs e)
        {
            Settings s1 = new Settings();
            this.Hide();
            s1.Show();
        }

        private void btnHomeForm_Click(object sender, EventArgs e)
        {
            HomeForm h = new HomeForm();
            this.Hide();
            h.Show();
        }

        private void btnAccountDetailsHomeForm_Click(object sender, EventArgs e)
        {
            AccountForm af = new AccountForm();
            af.Show();
            this.Hide();
        }

        private void btnPolicyHomeForm_Click(object sender, EventArgs e)
        {
            Policy p = new Policy();
            p.Show();
            this.Hide();
        }

        private void btnChargesScheduleHomeForm_Click(object sender, EventArgs e)
        {
            Charges ch = new Charges();
            ch.Show();
            this.Hide();
        }

        private void btnTransactionHistoryHomeForm_Click(object sender, EventArgs e)
        {
            TransactionHistory t = new TransactionHistory();
            t.Show();
            this.Hide();
        }

        private void btnManageCardMenuHomeForm_Click(object sender, EventArgs e)
        {
            CreditCardForm c = new CreditCardForm();
            c.Show();
            this.Hide();
        }
    }
}
