﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Fintech_Vaults.BusinessLayer;
using Fintech_Vaults.DataLayer;
namespace Fintech_Vaults.PresentationLayer
{
    public partial class Signup : Form
    {
        public Signup()
        {
            InitializeComponent();
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            User usr1 = new User();
            usr1.Password = txtPasswordSignUp.Text;
            string confirmPass = txtConfirmPasswordSignUp.Text;
            string firstName = txtFirstNameSignUp.Text;
            string lastName = txtLastNameSignUp.Text;
            usr1.Email = txtEmailSignUp.Text;
            usr1.MobileNo = long.Parse(txtMobileSignUp.Text);
            bool currentAccount = rdbtnCurrentAccountSignUp.Checked;
            bool savingAccount = rdbtnSavingAccountSignUp.Checked;
            if (usr1.Password == confirmPass && firstName != "" && lastName != "" && usr1.Email != "" && usr1.MobileNo > 0 && (currentAccount || savingAccount))
            {
                usr1.FullName = txtFirstNameSignUp.Text + " " + txtLastNameSignUp.Text;
                DBConnection.SignUpAccount(usr1);
                int userID = DBConnection.CheckUserIDForCreatingAccount(usr1);
                DBConnection.CreateAccountUsingUSerID(userID, currentAccount, savingAccount);
                int accountID = DBConnection.CheckingAccountIDForCreatingCredtiCard(userID);
                DateTime date = DateTime.Now;
                DateTime futureDate = date.AddYears(10);
                string expiryDate = futureDate.ToShortDateString();
                CreditCards c1 = new CreditCards();
                c1.AccountID = accountID;
                c1.CardName = firstName + " " + lastName;
                c1.ExpiryDate = expiryDate;
                DBConnection.CreateCreditCard(c1);
                Account acc1 = new Account();
                acc1.Card = c1;
                usr1.TheAccount = acc1;
                MessageBox.Show("Congratulations! Your account has been created successfully.", "Signed Up", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                LoginForm loginAccount = new LoginForm();
                loginAccount.Show();
                this.Hide();
            }
            else if (txtFirstNameSignUp.Text == "")
            {
                MessageBox.Show("Please enter your first name.", "Incomplete Detail", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txtLastNameSignUp.Text == "")
            {
                MessageBox.Show("Please enter your last name.", "Incomplete Detail", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txtEmailSignUp.Text == "")
            {
                MessageBox.Show("Please enter your email address.", "Incomplete Detail", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txtMobileSignUp.Text == "")
            {
                MessageBox.Show("Please enter your mobile number.", "Incomplete Detail", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txtPasswordSignUp.Text == "")
            {
                MessageBox.Show("Please enter your password.", "Incomplete Detail", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (!(rdbtnSavingAccountSignUp.Checked || rdbtnCurrentAccountSignUp.Checked))
            {
                MessageBox.Show("Please select the account type.", "Incomplete Detail", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("You have entered wrong password!\nPlease Enter the correct password again.", "Password Incorrect", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnShowPassowrdSignUp_Click(object sender, EventArgs e)
        {
            if (btnShowPassowrdSignUp.Text == "Hide")
            {
                txtPasswordSignUp.UseSystemPasswordChar = true;
                txtConfirmPasswordSignUp.UseSystemPasswordChar = true;
                btnShowPassowrdSignUp.Text = "Show";
            }
            else
            {
                txtPasswordSignUp.UseSystemPasswordChar = false;
                txtConfirmPasswordSignUp.UseSystemPasswordChar = false;
                btnShowPassowrdSignUp.Text = "Hide";
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Signup_Load(object sender, EventArgs e)
        {

        }
    }
}
