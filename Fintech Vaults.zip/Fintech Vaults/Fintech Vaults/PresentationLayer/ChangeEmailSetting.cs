﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Fintech_Vaults.BusinessLayer;
using Fintech_Vaults.DataLayer;
namespace Fintech_Vaults.PresentationLayer
{
    public partial class ChangeEmailSetting : Form
    {
        public ChangeEmailSetting()
        {
            InitializeComponent();
        }

        private void btnConfirmPassSetting_Click(object sender, EventArgs e)
        {
            string oldEmail = txtOldEmailCES.Text;
            string newEmail = txtNewEmailCES.Text;
            string confirmNewEmail = txtConfirmNewEmailCES.Text;
            Setting s1 = new Setting();
            //s1.ChangedPassword=
            if (newEmail == confirmNewEmail)
            {
                if (DBConnection.OldEmailCheckSetting(oldEmail))
                {
                    DBConnection.ChangeNewEmailSetting(newEmail);
                    MessageBox.Show("Email has been Changed!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("You have entered wrong Old Email!", "Wrong Old Email", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtOldEmailCES.Clear();
                }
            }
            else
            {
                MessageBox.Show("You have entered Wrond New Email\nOr Confirm New Email", "Wrong Info", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNewEmailCES.Clear();
                txtConfirmNewEmailCES.Clear();
            }
        }

        private void btnLogoutHomeForm_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }

        private void btnSettingsMenuHomeForm_Click(object sender, EventArgs e)
        {
            Settings s1 = new Settings();
            this.Hide();
            s1.Show();
        }

        private void btnAccountDetailsHomeForm_Click(object sender, EventArgs e)
        {
            AccountForm af = new AccountForm();
            af.Show();
            this.Hide();
        }

        private void btnHomeForm_Click(object sender, EventArgs e)
        {
            HomeForm h = new HomeForm();
            this.Hide();
            h.Show();
        }

        private void btnPolicyHomeForm_Click(object sender, EventArgs e)
        {
            Policy p = new Policy();
            p.Show();
            this.Hide();
        }

        private void btnChargesScheduleHomeForm_Click(object sender, EventArgs e)
        {
            Charges ch = new Charges();
            ch.Show();
            this.Hide();
        }

        private void btnTransactionHistoryHomeForm_Click(object sender, EventArgs e)
        {
            TransactionHistory t = new TransactionHistory();
            t.Show();
            this.Hide();
        }

        private void btnManageCardMenuHomeForm_Click(object sender, EventArgs e)
        {
            CreditCardForm c = new CreditCardForm();
            c.Show();
            this.Hide();
        }
    }
}
