﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Fintech_Vaults.BusinessLayer;
using Fintech_Vaults.DataLayer;
namespace Fintech_Vaults.PresentationLayer
{
    public partial class DepositMoney : Form
    {
        public DepositMoney()
        {
            InitializeComponent();
        }

        private void btnDepositMoney_Click(object sender, EventArgs e)
        {
            long amount = long.Parse(txtAmountDepositMoney.Text);
            string pass = txtPassDepositMoney.Text;
            if (DBConnection.MatchPassword(pass))
            {
                DBConnection.DepositAmount(amount);
                MessageBox.Show("Amount has been deposited successfully!.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtAmountDepositMoney.Clear();
                txtPassDepositMoney.Clear();
            }
            else
            {
                MessageBox.Show("You have entered wrong Password!\nPLease Try Again.", "Incorrect Password", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPassDepositMoney.Clear();
            }
        }

        private void btnHomeForm_Click(object sender, EventArgs e)
        {
            HomeForm hf1 = new HomeForm();
            this.Hide();
            hf1.Show();
        }

        private void btnAccountDetailsHomeForm_Click(object sender, EventArgs e)
        {
            AccountForm af1 = new AccountForm();
            af1.Show();
            this.Hide();
        }

        private void btnShowPassAccountForm_Click(object sender, EventArgs e)
        {
            if (btnShowPassDepositMoney.Text == "Hide")
            {
                txtPassDepositMoney.UseSystemPasswordChar = true;
                btnShowPassDepositMoney.Text = "Show";
            }
            else
            {
                txtPassDepositMoney.UseSystemPasswordChar = false;
                btnShowPassDepositMoney.Text = "Hide";
            }
        }

        private void btnLogoutHomeForm_Click(object sender, EventArgs e)
        {
            HomeForm hf1 = new HomeForm();
            hf1.Show();
            this.Hide();
        }

        private void btnSettingsMenuHomeForm_Click(object sender, EventArgs e)
        {
            Settings s1 = new Settings();
            this.Hide();
            s1.Show();
        }

        private void btnPolicyHomeForm_Click(object sender, EventArgs e)
        {
            Policy p = new Policy();
            p.Show();
            this.Hide();
        }

        private void btnChargesScheduleHomeForm_Click(object sender, EventArgs e)
        {
            Charges ch = new Charges();
            ch.Show();
            this.Hide();
        }

        private void btnTransactionHistoryHomeForm_Click(object sender, EventArgs e)
        {
            TransactionHistory t = new TransactionHistory();
            t.Show();
            this.Hide();
        }

        private void btnManageCardMenuHomeForm_Click(object sender, EventArgs e)
        {
            CreditCardForm c = new CreditCardForm();
            c.Show();
            this.Hide();
        }
    }
}
