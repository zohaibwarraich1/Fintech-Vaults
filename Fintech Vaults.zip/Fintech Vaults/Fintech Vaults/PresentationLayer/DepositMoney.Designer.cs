﻿
namespace Fintech_Vaults.PresentationLayer
{
    partial class DepositMoney
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuDepositMoney = new System.Windows.Forms.Panel();
            this.btnLogoutHomeForm = new System.Windows.Forms.Button();
            this.btnSettingsMenuHomeForm = new System.Windows.Forms.Button();
            this.btnPolicyHomeForm = new System.Windows.Forms.Button();
            this.btnChargesScheduleHomeForm = new System.Windows.Forms.Button();
            this.btnManageCardMenuHomeForm = new System.Windows.Forms.Button();
            this.btnTransactionHistoryHomeForm = new System.Windows.Forms.Button();
            this.btnHomeForm = new System.Windows.Forms.Button();
            this.btnAccountDetailsHomeForm = new System.Windows.Forms.Button();
            this.picboxBankLogo = new System.Windows.Forms.PictureBox();
            this.txtAmountDepositMoney = new System.Windows.Forms.TextBox();
            this.lblAmountDeppositMoney = new System.Windows.Forms.Label();
            this.lblPassDepositMoney = new System.Windows.Forms.Label();
            this.txtPassDepositMoney = new System.Windows.Forms.TextBox();
            this.btnDepositMoney = new System.Windows.Forms.Button();
            this.btnShowPassDepositMoney = new System.Windows.Forms.Button();
            this.menuDepositMoney.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picboxBankLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // menuDepositMoney
            // 
            this.menuDepositMoney.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.menuDepositMoney.Controls.Add(this.btnLogoutHomeForm);
            this.menuDepositMoney.Controls.Add(this.btnSettingsMenuHomeForm);
            this.menuDepositMoney.Controls.Add(this.btnPolicyHomeForm);
            this.menuDepositMoney.Controls.Add(this.btnChargesScheduleHomeForm);
            this.menuDepositMoney.Controls.Add(this.btnManageCardMenuHomeForm);
            this.menuDepositMoney.Controls.Add(this.btnTransactionHistoryHomeForm);
            this.menuDepositMoney.Controls.Add(this.btnHomeForm);
            this.menuDepositMoney.Controls.Add(this.btnAccountDetailsHomeForm);
            this.menuDepositMoney.Controls.Add(this.picboxBankLogo);
            this.menuDepositMoney.Location = new System.Drawing.Point(-11, -22);
            this.menuDepositMoney.Margin = new System.Windows.Forms.Padding(2);
            this.menuDepositMoney.Name = "menuDepositMoney";
            this.menuDepositMoney.Size = new System.Drawing.Size(197, 732);
            this.menuDepositMoney.TabIndex = 1;
            // 
            // btnLogoutHomeForm
            // 
            this.btnLogoutHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLogoutHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_logout_30;
            this.btnLogoutHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnLogoutHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogoutHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLogoutHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogoutHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnLogoutHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnLogoutHomeForm.Location = new System.Drawing.Point(23, 558);
            this.btnLogoutHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnLogoutHomeForm.Name = "btnLogoutHomeForm";
            this.btnLogoutHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnLogoutHomeForm.Size = new System.Drawing.Size(158, 33);
            this.btnLogoutHomeForm.TabIndex = 8;
            this.btnLogoutHomeForm.Text = "Logout";
            this.btnLogoutHomeForm.UseVisualStyleBackColor = false;
            this.btnLogoutHomeForm.Click += new System.EventHandler(this.btnLogoutHomeForm_Click);
            // 
            // btnSettingsMenuHomeForm
            // 
            this.btnSettingsMenuHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnSettingsMenuHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_setting_30;
            this.btnSettingsMenuHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSettingsMenuHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSettingsMenuHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSettingsMenuHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettingsMenuHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnSettingsMenuHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnSettingsMenuHomeForm.Location = new System.Drawing.Point(23, 505);
            this.btnSettingsMenuHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnSettingsMenuHomeForm.Name = "btnSettingsMenuHomeForm";
            this.btnSettingsMenuHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnSettingsMenuHomeForm.Size = new System.Drawing.Size(158, 32);
            this.btnSettingsMenuHomeForm.TabIndex = 7;
            this.btnSettingsMenuHomeForm.Text = "Settings";
            this.btnSettingsMenuHomeForm.UseVisualStyleBackColor = false;
            this.btnSettingsMenuHomeForm.Click += new System.EventHandler(this.btnSettingsMenuHomeForm_Click);
            // 
            // btnPolicyHomeForm
            // 
            this.btnPolicyHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnPolicyHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_policy_30;
            this.btnPolicyHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnPolicyHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPolicyHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPolicyHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPolicyHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnPolicyHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnPolicyHomeForm.Location = new System.Drawing.Point(23, 451);
            this.btnPolicyHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnPolicyHomeForm.Name = "btnPolicyHomeForm";
            this.btnPolicyHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnPolicyHomeForm.Size = new System.Drawing.Size(158, 34);
            this.btnPolicyHomeForm.TabIndex = 6;
            this.btnPolicyHomeForm.Text = "Policy";
            this.btnPolicyHomeForm.UseVisualStyleBackColor = false;
            this.btnPolicyHomeForm.Click += new System.EventHandler(this.btnPolicyHomeForm_Click);
            // 
            // btnChargesScheduleHomeForm
            // 
            this.btnChargesScheduleHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnChargesScheduleHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_pay_wall_50;
            this.btnChargesScheduleHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnChargesScheduleHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChargesScheduleHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnChargesScheduleHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChargesScheduleHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnChargesScheduleHomeForm.Location = new System.Drawing.Point(23, 381);
            this.btnChargesScheduleHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnChargesScheduleHomeForm.Name = "btnChargesScheduleHomeForm";
            this.btnChargesScheduleHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnChargesScheduleHomeForm.Size = new System.Drawing.Size(158, 53);
            this.btnChargesScheduleHomeForm.TabIndex = 5;
            this.btnChargesScheduleHomeForm.Text = "Charges Schedule";
            this.btnChargesScheduleHomeForm.UseVisualStyleBackColor = false;
            this.btnChargesScheduleHomeForm.Click += new System.EventHandler(this.btnChargesScheduleHomeForm_Click);
            // 
            // btnManageCardMenuHomeForm
            // 
            this.btnManageCardMenuHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnManageCardMenuHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_card_30__1_;
            this.btnManageCardMenuHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnManageCardMenuHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnManageCardMenuHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnManageCardMenuHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManageCardMenuHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnManageCardMenuHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnManageCardMenuHomeForm.Location = new System.Drawing.Point(23, 327);
            this.btnManageCardMenuHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnManageCardMenuHomeForm.Name = "btnManageCardMenuHomeForm";
            this.btnManageCardMenuHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnManageCardMenuHomeForm.Size = new System.Drawing.Size(158, 30);
            this.btnManageCardMenuHomeForm.TabIndex = 4;
            this.btnManageCardMenuHomeForm.Text = "Manage Card";
            this.btnManageCardMenuHomeForm.UseVisualStyleBackColor = false;
            this.btnManageCardMenuHomeForm.Click += new System.EventHandler(this.btnManageCardMenuHomeForm_Click);
            // 
            // btnTransactionHistoryHomeForm
            // 
            this.btnTransactionHistoryHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnTransactionHistoryHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_transaction_501;
            this.btnTransactionHistoryHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnTransactionHistoryHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTransactionHistoryHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTransactionHistoryHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTransactionHistoryHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnTransactionHistoryHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnTransactionHistoryHomeForm.Location = new System.Drawing.Point(23, 254);
            this.btnTransactionHistoryHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnTransactionHistoryHomeForm.Name = "btnTransactionHistoryHomeForm";
            this.btnTransactionHistoryHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnTransactionHistoryHomeForm.Size = new System.Drawing.Size(158, 52);
            this.btnTransactionHistoryHomeForm.TabIndex = 3;
            this.btnTransactionHistoryHomeForm.Text = "Transaction History";
            this.btnTransactionHistoryHomeForm.UseVisualStyleBackColor = false;
            this.btnTransactionHistoryHomeForm.Click += new System.EventHandler(this.btnTransactionHistoryHomeForm_Click);
            // 
            // btnHomeForm
            // 
            this.btnHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_home_30;
            this.btnHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnHomeForm.Location = new System.Drawing.Point(23, 203);
            this.btnHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnHomeForm.Name = "btnHomeForm";
            this.btnHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnHomeForm.Size = new System.Drawing.Size(158, 31);
            this.btnHomeForm.TabIndex = 2;
            this.btnHomeForm.Text = "Home";
            this.btnHomeForm.UseVisualStyleBackColor = false;
            this.btnHomeForm.Click += new System.EventHandler(this.btnHomeForm_Click);
            // 
            // btnAccountDetailsHomeForm
            // 
            this.btnAccountDetailsHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnAccountDetailsHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_account_30;
            this.btnAccountDetailsHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnAccountDetailsHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAccountDetailsHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAccountDetailsHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAccountDetailsHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnAccountDetailsHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnAccountDetailsHomeForm.Location = new System.Drawing.Point(23, 154);
            this.btnAccountDetailsHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnAccountDetailsHomeForm.Name = "btnAccountDetailsHomeForm";
            this.btnAccountDetailsHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnAccountDetailsHomeForm.Size = new System.Drawing.Size(158, 31);
            this.btnAccountDetailsHomeForm.TabIndex = 1;
            this.btnAccountDetailsHomeForm.Text = "Account Details";
            this.btnAccountDetailsHomeForm.UseVisualStyleBackColor = false;
            this.btnAccountDetailsHomeForm.Click += new System.EventHandler(this.btnAccountDetailsHomeForm_Click);
            // 
            // picboxBankLogo
            // 
            this.picboxBankLogo.Image = global::Fintech_Vaults.Properties.Resources.attachment_62465982_removebg_preview;
            this.picboxBankLogo.Location = new System.Drawing.Point(0, 21);
            this.picboxBankLogo.Margin = new System.Windows.Forms.Padding(2);
            this.picboxBankLogo.Name = "picboxBankLogo";
            this.picboxBankLogo.Size = new System.Drawing.Size(221, 119);
            this.picboxBankLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picboxBankLogo.TabIndex = 0;
            this.picboxBankLogo.TabStop = false;
            // 
            // txtAmountDepositMoney
            // 
            this.txtAmountDepositMoney.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAmountDepositMoney.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAmountDepositMoney.Location = new System.Drawing.Point(333, 189);
            this.txtAmountDepositMoney.Name = "txtAmountDepositMoney";
            this.txtAmountDepositMoney.Size = new System.Drawing.Size(236, 31);
            this.txtAmountDepositMoney.TabIndex = 44;
            // 
            // lblAmountDeppositMoney
            // 
            this.lblAmountDeppositMoney.AutoSize = true;
            this.lblAmountDeppositMoney.Font = new System.Drawing.Font("Microsoft Tai Le", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAmountDeppositMoney.Location = new System.Drawing.Point(201, 189);
            this.lblAmountDeppositMoney.Name = "lblAmountDeppositMoney";
            this.lblAmountDeppositMoney.Size = new System.Drawing.Size(126, 34);
            this.lblAmountDeppositMoney.TabIndex = 45;
            this.lblAmountDeppositMoney.Text = "Amount:";
            // 
            // lblPassDepositMoney
            // 
            this.lblPassDepositMoney.AutoSize = true;
            this.lblPassDepositMoney.Font = new System.Drawing.Font("Microsoft Tai Le", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPassDepositMoney.Location = new System.Drawing.Point(614, 189);
            this.lblPassDepositMoney.Name = "lblPassDepositMoney";
            this.lblPassDepositMoney.Size = new System.Drawing.Size(145, 34);
            this.lblPassDepositMoney.TabIndex = 46;
            this.lblPassDepositMoney.Text = "Password:";
            // 
            // txtPassDepositMoney
            // 
            this.txtPassDepositMoney.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPassDepositMoney.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassDepositMoney.Location = new System.Drawing.Point(765, 189);
            this.txtPassDepositMoney.Name = "txtPassDepositMoney";
            this.txtPassDepositMoney.Size = new System.Drawing.Size(236, 31);
            this.txtPassDepositMoney.TabIndex = 47;
            this.txtPassDepositMoney.UseSystemPasswordChar = true;
            // 
            // btnDepositMoney
            // 
            this.btnDepositMoney.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnDepositMoney.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDepositMoney.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDepositMoney.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDepositMoney.Font = new System.Drawing.Font("Microsoft PhagsPa", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDepositMoney.ForeColor = System.Drawing.Color.Black;
            this.btnDepositMoney.Location = new System.Drawing.Point(433, 408);
            this.btnDepositMoney.Margin = new System.Windows.Forms.Padding(2);
            this.btnDepositMoney.Name = "btnDepositMoney";
            this.btnDepositMoney.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnDepositMoney.Size = new System.Drawing.Size(241, 55);
            this.btnDepositMoney.TabIndex = 48;
            this.btnDepositMoney.Text = "Deposit";
            this.btnDepositMoney.UseVisualStyleBackColor = false;
            this.btnDepositMoney.Click += new System.EventHandler(this.btnDepositMoney_Click);
            // 
            // btnShowPassDepositMoney
            // 
            this.btnShowPassDepositMoney.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnShowPassDepositMoney.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnShowPassDepositMoney.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnShowPassDepositMoney.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnShowPassDepositMoney.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowPassDepositMoney.ForeColor = System.Drawing.Color.Black;
            this.btnShowPassDepositMoney.Location = new System.Drawing.Point(830, 241);
            this.btnShowPassDepositMoney.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.btnShowPassDepositMoney.Name = "btnShowPassDepositMoney";
            this.btnShowPassDepositMoney.Size = new System.Drawing.Size(93, 43);
            this.btnShowPassDepositMoney.TabIndex = 49;
            this.btnShowPassDepositMoney.Text = "Show";
            this.btnShowPassDepositMoney.UseVisualStyleBackColor = false;
            this.btnShowPassDepositMoney.Click += new System.EventHandler(this.btnShowPassAccountForm_Click);
            // 
            // DepositMoney
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(1022, 586);
            this.Controls.Add(this.btnShowPassDepositMoney);
            this.Controls.Add(this.btnDepositMoney);
            this.Controls.Add(this.txtPassDepositMoney);
            this.Controls.Add(this.lblPassDepositMoney);
            this.Controls.Add(this.lblAmountDeppositMoney);
            this.Controls.Add(this.txtAmountDepositMoney);
            this.Controls.Add(this.menuDepositMoney);
            this.Name = "DepositMoney";
            this.Text = "DepositMoney";
            this.menuDepositMoney.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picboxBankLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel menuDepositMoney;
        private System.Windows.Forms.Button btnLogoutHomeForm;
        private System.Windows.Forms.Button btnSettingsMenuHomeForm;
        private System.Windows.Forms.Button btnPolicyHomeForm;
        private System.Windows.Forms.Button btnChargesScheduleHomeForm;
        private System.Windows.Forms.Button btnManageCardMenuHomeForm;
        private System.Windows.Forms.Button btnTransactionHistoryHomeForm;
        private System.Windows.Forms.Button btnHomeForm;
        private System.Windows.Forms.Button btnAccountDetailsHomeForm;
        private System.Windows.Forms.PictureBox picboxBankLogo;
        private System.Windows.Forms.TextBox txtAmountDepositMoney;
        private System.Windows.Forms.Label lblAmountDeppositMoney;
        private System.Windows.Forms.Label lblPassDepositMoney;
        private System.Windows.Forms.TextBox txtPassDepositMoney;
        private System.Windows.Forms.Button btnDepositMoney;
        private System.Windows.Forms.Button btnShowPassDepositMoney;
    }
}