﻿
namespace Fintech_Vaults.PresentationLayer
{
    partial class CardActivation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuDepositMoney = new System.Windows.Forms.Panel();
            this.btnLogoutHomeForm = new System.Windows.Forms.Button();
            this.btnSettingsMenuHomeForm = new System.Windows.Forms.Button();
            this.btnPolicyHomeForm = new System.Windows.Forms.Button();
            this.btnChargesScheduleHomeForm = new System.Windows.Forms.Button();
            this.btnManageCardMenuHomeForm = new System.Windows.Forms.Button();
            this.btnTransactionHistoryHomeForm = new System.Windows.Forms.Button();
            this.btnHomeForm = new System.Windows.Forms.Button();
            this.btnAccountDetailsHomeForm = new System.Windows.Forms.Button();
            this.picboxBankLogo = new System.Windows.Forms.PictureBox();
            this.lblAccountOverviewAccountForm = new System.Windows.Forms.Label();
            this.txtChangePin = new System.Windows.Forms.TextBox();
            this.lblBeneficiaryAccountNoBAD = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDone = new System.Windows.Forms.Button();
            this.menuDepositMoney.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picboxBankLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // menuDepositMoney
            // 
            this.menuDepositMoney.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.menuDepositMoney.Controls.Add(this.btnLogoutHomeForm);
            this.menuDepositMoney.Controls.Add(this.btnSettingsMenuHomeForm);
            this.menuDepositMoney.Controls.Add(this.btnPolicyHomeForm);
            this.menuDepositMoney.Controls.Add(this.btnChargesScheduleHomeForm);
            this.menuDepositMoney.Controls.Add(this.btnManageCardMenuHomeForm);
            this.menuDepositMoney.Controls.Add(this.btnTransactionHistoryHomeForm);
            this.menuDepositMoney.Controls.Add(this.btnHomeForm);
            this.menuDepositMoney.Controls.Add(this.btnAccountDetailsHomeForm);
            this.menuDepositMoney.Controls.Add(this.picboxBankLogo);
            this.menuDepositMoney.Location = new System.Drawing.Point(-24, -42);
            this.menuDepositMoney.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.menuDepositMoney.Name = "menuDepositMoney";
            this.menuDepositMoney.Size = new System.Drawing.Size(394, 1408);
            this.menuDepositMoney.TabIndex = 6;
            // 
            // btnLogoutHomeForm
            // 
            this.btnLogoutHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLogoutHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_logout_30;
            this.btnLogoutHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnLogoutHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogoutHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLogoutHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogoutHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnLogoutHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnLogoutHomeForm.Location = new System.Drawing.Point(46, 1073);
            this.btnLogoutHomeForm.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLogoutHomeForm.Name = "btnLogoutHomeForm";
            this.btnLogoutHomeForm.Padding = new System.Windows.Forms.Padding(60, 4, 0, 0);
            this.btnLogoutHomeForm.Size = new System.Drawing.Size(316, 63);
            this.btnLogoutHomeForm.TabIndex = 8;
            this.btnLogoutHomeForm.Text = "Logout";
            this.btnLogoutHomeForm.UseVisualStyleBackColor = false;
            this.btnLogoutHomeForm.Click += new System.EventHandler(this.btnLogoutHomeForm_Click);
            // 
            // btnSettingsMenuHomeForm
            // 
            this.btnSettingsMenuHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnSettingsMenuHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_setting_30;
            this.btnSettingsMenuHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSettingsMenuHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSettingsMenuHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSettingsMenuHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettingsMenuHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnSettingsMenuHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnSettingsMenuHomeForm.Location = new System.Drawing.Point(46, 971);
            this.btnSettingsMenuHomeForm.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSettingsMenuHomeForm.Name = "btnSettingsMenuHomeForm";
            this.btnSettingsMenuHomeForm.Padding = new System.Windows.Forms.Padding(60, 4, 0, 0);
            this.btnSettingsMenuHomeForm.Size = new System.Drawing.Size(316, 62);
            this.btnSettingsMenuHomeForm.TabIndex = 7;
            this.btnSettingsMenuHomeForm.Text = "Settings";
            this.btnSettingsMenuHomeForm.UseVisualStyleBackColor = false;
            this.btnSettingsMenuHomeForm.Click += new System.EventHandler(this.btnSettingsMenuHomeForm_Click);
            // 
            // btnPolicyHomeForm
            // 
            this.btnPolicyHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnPolicyHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_policy_30;
            this.btnPolicyHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnPolicyHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPolicyHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPolicyHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPolicyHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnPolicyHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnPolicyHomeForm.Location = new System.Drawing.Point(46, 867);
            this.btnPolicyHomeForm.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPolicyHomeForm.Name = "btnPolicyHomeForm";
            this.btnPolicyHomeForm.Padding = new System.Windows.Forms.Padding(60, 4, 0, 0);
            this.btnPolicyHomeForm.Size = new System.Drawing.Size(316, 65);
            this.btnPolicyHomeForm.TabIndex = 6;
            this.btnPolicyHomeForm.Text = "Policy";
            this.btnPolicyHomeForm.UseVisualStyleBackColor = false;
            this.btnPolicyHomeForm.Click += new System.EventHandler(this.btnPolicyHomeForm_Click);
            // 
            // btnChargesScheduleHomeForm
            // 
            this.btnChargesScheduleHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnChargesScheduleHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_pay_wall_50;
            this.btnChargesScheduleHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnChargesScheduleHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChargesScheduleHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnChargesScheduleHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChargesScheduleHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnChargesScheduleHomeForm.Location = new System.Drawing.Point(46, 733);
            this.btnChargesScheduleHomeForm.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnChargesScheduleHomeForm.Name = "btnChargesScheduleHomeForm";
            this.btnChargesScheduleHomeForm.Padding = new System.Windows.Forms.Padding(60, 4, 0, 0);
            this.btnChargesScheduleHomeForm.Size = new System.Drawing.Size(316, 102);
            this.btnChargesScheduleHomeForm.TabIndex = 5;
            this.btnChargesScheduleHomeForm.Text = "Charges Schedule";
            this.btnChargesScheduleHomeForm.UseVisualStyleBackColor = false;
            this.btnChargesScheduleHomeForm.Click += new System.EventHandler(this.btnChargesScheduleHomeForm_Click);
            // 
            // btnManageCardMenuHomeForm
            // 
            this.btnManageCardMenuHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnManageCardMenuHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_card_30__1_;
            this.btnManageCardMenuHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnManageCardMenuHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnManageCardMenuHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnManageCardMenuHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManageCardMenuHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnManageCardMenuHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnManageCardMenuHomeForm.Location = new System.Drawing.Point(46, 629);
            this.btnManageCardMenuHomeForm.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnManageCardMenuHomeForm.Name = "btnManageCardMenuHomeForm";
            this.btnManageCardMenuHomeForm.Padding = new System.Windows.Forms.Padding(60, 4, 0, 0);
            this.btnManageCardMenuHomeForm.Size = new System.Drawing.Size(316, 58);
            this.btnManageCardMenuHomeForm.TabIndex = 4;
            this.btnManageCardMenuHomeForm.Text = "Manage Card";
            this.btnManageCardMenuHomeForm.UseVisualStyleBackColor = false;
            this.btnManageCardMenuHomeForm.Click += new System.EventHandler(this.btnManageCardMenuHomeForm_Click);
            // 
            // btnTransactionHistoryHomeForm
            // 
            this.btnTransactionHistoryHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnTransactionHistoryHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_transaction_501;
            this.btnTransactionHistoryHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnTransactionHistoryHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTransactionHistoryHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTransactionHistoryHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTransactionHistoryHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnTransactionHistoryHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnTransactionHistoryHomeForm.Location = new System.Drawing.Point(46, 488);
            this.btnTransactionHistoryHomeForm.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTransactionHistoryHomeForm.Name = "btnTransactionHistoryHomeForm";
            this.btnTransactionHistoryHomeForm.Padding = new System.Windows.Forms.Padding(60, 4, 0, 0);
            this.btnTransactionHistoryHomeForm.Size = new System.Drawing.Size(316, 100);
            this.btnTransactionHistoryHomeForm.TabIndex = 3;
            this.btnTransactionHistoryHomeForm.Text = "Transaction History";
            this.btnTransactionHistoryHomeForm.UseVisualStyleBackColor = false;
            this.btnTransactionHistoryHomeForm.Click += new System.EventHandler(this.btnTransactionHistoryHomeForm_Click);
            // 
            // btnHomeForm
            // 
            this.btnHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_home_30;
            this.btnHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnHomeForm.Location = new System.Drawing.Point(46, 390);
            this.btnHomeForm.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnHomeForm.Name = "btnHomeForm";
            this.btnHomeForm.Padding = new System.Windows.Forms.Padding(60, 4, 0, 0);
            this.btnHomeForm.Size = new System.Drawing.Size(316, 60);
            this.btnHomeForm.TabIndex = 2;
            this.btnHomeForm.Text = "Home";
            this.btnHomeForm.UseVisualStyleBackColor = false;
            this.btnHomeForm.Click += new System.EventHandler(this.btnHomeForm_Click);
            // 
            // btnAccountDetailsHomeForm
            // 
            this.btnAccountDetailsHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnAccountDetailsHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_account_30;
            this.btnAccountDetailsHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnAccountDetailsHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAccountDetailsHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAccountDetailsHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAccountDetailsHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnAccountDetailsHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnAccountDetailsHomeForm.Location = new System.Drawing.Point(46, 296);
            this.btnAccountDetailsHomeForm.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAccountDetailsHomeForm.Name = "btnAccountDetailsHomeForm";
            this.btnAccountDetailsHomeForm.Padding = new System.Windows.Forms.Padding(60, 4, 0, 0);
            this.btnAccountDetailsHomeForm.Size = new System.Drawing.Size(316, 60);
            this.btnAccountDetailsHomeForm.TabIndex = 1;
            this.btnAccountDetailsHomeForm.Text = "Account Details";
            this.btnAccountDetailsHomeForm.UseVisualStyleBackColor = false;
            this.btnAccountDetailsHomeForm.Click += new System.EventHandler(this.btnAccountDetailsHomeForm_Click);
            // 
            // picboxBankLogo
            // 
            this.picboxBankLogo.Image = global::Fintech_Vaults.Properties.Resources.attachment_62465982_removebg_preview;
            this.picboxBankLogo.Location = new System.Drawing.Point(0, 40);
            this.picboxBankLogo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picboxBankLogo.Name = "picboxBankLogo";
            this.picboxBankLogo.Size = new System.Drawing.Size(442, 229);
            this.picboxBankLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picboxBankLogo.TabIndex = 0;
            this.picboxBankLogo.TabStop = false;
            // 
            // lblAccountOverviewAccountForm
            // 
            this.lblAccountOverviewAccountForm.AutoSize = true;
            this.lblAccountOverviewAccountForm.Font = new System.Drawing.Font("Bookman Old Style", 32.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccountOverviewAccountForm.Location = new System.Drawing.Point(812, 185);
            this.lblAccountOverviewAccountForm.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblAccountOverviewAccountForm.Name = "lblAccountOverviewAccountForm";
            this.lblAccountOverviewAccountForm.Size = new System.Drawing.Size(747, 100);
            this.lblAccountOverviewAccountForm.TabIndex = 50;
            this.lblAccountOverviewAccountForm.Text = "Card Activation";
            // 
            // txtChangePin
            // 
            this.txtChangePin.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtChangePin.Location = new System.Drawing.Point(762, 446);
            this.txtChangePin.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtChangePin.Name = "txtChangePin";
            this.txtChangePin.Size = new System.Drawing.Size(638, 69);
            this.txtChangePin.TabIndex = 52;
            // 
            // lblBeneficiaryAccountNoBAD
            // 
            this.lblBeneficiaryAccountNoBAD.AutoSize = true;
            this.lblBeneficiaryAccountNoBAD.BackColor = System.Drawing.Color.Transparent;
            this.lblBeneficiaryAccountNoBAD.Font = new System.Drawing.Font("Microsoft PhagsPa", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBeneficiaryAccountNoBAD.Location = new System.Drawing.Point(516, 446);
            this.lblBeneficiaryAccountNoBAD.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBeneficiaryAccountNoBAD.Name = "lblBeneficiaryAccountNoBAD";
            this.lblBeneficiaryAccountNoBAD.Size = new System.Drawing.Size(230, 63);
            this.lblBeneficiaryAccountNoBAD.TabIndex = 51;
            this.lblBeneficiaryAccountNoBAD.Text = "Card Pin:";
            // 
            // txtPassword
            // 
            this.txtPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.Location = new System.Drawing.Point(782, 573);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(638, 69);
            this.txtPassword.TabIndex = 54;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft PhagsPa", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(516, 573);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(253, 63);
            this.label1.TabIndex = 53;
            this.label1.Text = "Password:";
            // 
            // btnDone
            // 
            this.btnDone.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnDone.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnDone.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDone.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDone.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDone.ForeColor = System.Drawing.Color.Black;
            this.btnDone.Location = new System.Drawing.Point(934, 796);
            this.btnDone.Margin = new System.Windows.Forms.Padding(12, 15, 12, 15);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(370, 125);
            this.btnDone.TabIndex = 56;
            this.btnDone.Text = "Activate Card";
            this.btnDone.UseVisualStyleBackColor = false;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // CardActivation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(2044, 1127);
            this.Controls.Add(this.btnDone);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtChangePin);
            this.Controls.Add(this.lblBeneficiaryAccountNoBAD);
            this.Controls.Add(this.lblAccountOverviewAccountForm);
            this.Controls.Add(this.menuDepositMoney);
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "CardActivation";
            this.Text = "CardActivation";
            this.Load += new System.EventHandler(this.CardActivation_Load);
            this.menuDepositMoney.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picboxBankLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel menuDepositMoney;
        private System.Windows.Forms.Button btnLogoutHomeForm;
        private System.Windows.Forms.Button btnSettingsMenuHomeForm;
        private System.Windows.Forms.Button btnPolicyHomeForm;
        private System.Windows.Forms.Button btnChargesScheduleHomeForm;
        private System.Windows.Forms.Button btnManageCardMenuHomeForm;
        private System.Windows.Forms.Button btnTransactionHistoryHomeForm;
        private System.Windows.Forms.Button btnHomeForm;
        private System.Windows.Forms.Button btnAccountDetailsHomeForm;
        private System.Windows.Forms.PictureBox picboxBankLogo;
        private System.Windows.Forms.Label lblAccountOverviewAccountForm;
        private System.Windows.Forms.TextBox txtChangePin;
        private System.Windows.Forms.Label lblBeneficiaryAccountNoBAD;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDone;
    }
}