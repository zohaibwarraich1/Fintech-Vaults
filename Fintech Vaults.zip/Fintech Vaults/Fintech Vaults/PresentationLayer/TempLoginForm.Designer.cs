﻿
namespace Fintech_Vaults.PresentationLayer
{
    partial class TempLoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblIntroLoginPage = new System.Windows.Forms.Label();
            this.lblUserLogin = new System.Windows.Forms.Label();
            this.picboxBankLogo = new System.Windows.Forms.PictureBox();
            this.lblLoginPassword = new System.Windows.Forms.Label();
            this.txtLoginPassword = new System.Windows.Forms.TextBox();
            this.lblLoginEmail = new System.Windows.Forms.Label();
            this.txtLoginEmail = new System.Windows.Forms.TextBox();
            this.btnShowPassowrdLogin = new System.Windows.Forms.Button();
            this.btnLogin = new System.Windows.Forms.Button();
            this.lblSignUpNewLogin = new System.Windows.Forms.Label();
            this.lblDontHaveAccount2Login = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picboxBankLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.lblSignUpNewLogin);
            this.panel1.Controls.Add(this.lblDontHaveAccount2Login);
            this.panel1.Controls.Add(this.btnShowPassowrdLogin);
            this.panel1.Controls.Add(this.btnLogin);
            this.panel1.Controls.Add(this.lblLoginPassword);
            this.panel1.Controls.Add(this.txtLoginPassword);
            this.panel1.Controls.Add(this.lblLoginEmail);
            this.panel1.Controls.Add(this.txtLoginEmail);
            this.panel1.Controls.Add(this.picboxBankLogo);
            this.panel1.Controls.Add(this.lblIntroLoginPage);
            this.panel1.Controls.Add(this.lblUserLogin);
            this.panel1.Location = new System.Drawing.Point(286, -3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(454, 591);
            this.panel1.TabIndex = 0;
            // 
            // lblIntroLoginPage
            // 
            this.lblIntroLoginPage.AutoSize = true;
            this.lblIntroLoginPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIntroLoginPage.ForeColor = System.Drawing.Color.Black;
            this.lblIntroLoginPage.Location = new System.Drawing.Point(5, 217);
            this.lblIntroLoginPage.Name = "lblIntroLoginPage";
            this.lblIntroLoginPage.Size = new System.Drawing.Size(445, 48);
            this.lblIntroLoginPage.TabIndex = 3;
            this.lblIntroLoginPage.Text = "Welcome to our secure banking portal. Please enter\r\nyour credentials to access yo" +
    "ur account.";
            // 
            // lblUserLogin
            // 
            this.lblUserLogin.AutoSize = true;
            this.lblUserLogin.BackColor = System.Drawing.Color.Transparent;
            this.lblUserLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserLogin.ForeColor = System.Drawing.Color.Black;
            this.lblUserLogin.Location = new System.Drawing.Point(148, 173);
            this.lblUserLogin.Name = "lblUserLogin";
            this.lblUserLogin.Size = new System.Drawing.Size(153, 33);
            this.lblUserLogin.TabIndex = 2;
            this.lblUserLogin.Text = "Welcome!";
            // 
            // picboxBankLogo
            // 
            this.picboxBankLogo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picboxBankLogo.Image = global::Fintech_Vaults.Properties.Resources.attachment_62465982_removebg_preview;
            this.picboxBankLogo.Location = new System.Drawing.Point(0, 2);
            this.picboxBankLogo.Margin = new System.Windows.Forms.Padding(2);
            this.picboxBankLogo.Name = "picboxBankLogo";
            this.picboxBankLogo.Size = new System.Drawing.Size(456, 167);
            this.picboxBankLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picboxBankLogo.TabIndex = 4;
            this.picboxBankLogo.TabStop = false;
            // 
            // lblLoginPassword
            // 
            this.lblLoginPassword.AutoSize = true;
            this.lblLoginPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoginPassword.ForeColor = System.Drawing.Color.Black;
            this.lblLoginPassword.Location = new System.Drawing.Point(11, 356);
            this.lblLoginPassword.Name = "lblLoginPassword";
            this.lblLoginPassword.Size = new System.Drawing.Size(112, 25);
            this.lblLoginPassword.TabIndex = 10;
            this.lblLoginPassword.Text = "Password:";
            // 
            // txtLoginPassword
            // 
            this.txtLoginPassword.BackColor = System.Drawing.Color.White;
            this.txtLoginPassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLoginPassword.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLoginPassword.ForeColor = System.Drawing.Color.Black;
            this.txtLoginPassword.Location = new System.Drawing.Point(15, 384);
            this.txtLoginPassword.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtLoginPassword.Name = "txtLoginPassword";
            this.txtLoginPassword.Size = new System.Drawing.Size(422, 38);
            this.txtLoginPassword.TabIndex = 9;
            this.txtLoginPassword.Tag = "";
            this.txtLoginPassword.UseSystemPasswordChar = true;
            // 
            // lblLoginEmail
            // 
            this.lblLoginEmail.AutoSize = true;
            this.lblLoginEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoginEmail.ForeColor = System.Drawing.Color.Black;
            this.lblLoginEmail.Location = new System.Drawing.Point(11, 279);
            this.lblLoginEmail.Name = "lblLoginEmail";
            this.lblLoginEmail.Size = new System.Drawing.Size(71, 25);
            this.lblLoginEmail.TabIndex = 8;
            this.lblLoginEmail.Text = "Email:";
            // 
            // txtLoginEmail
            // 
            this.txtLoginEmail.BackColor = System.Drawing.Color.White;
            this.txtLoginEmail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLoginEmail.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLoginEmail.ForeColor = System.Drawing.Color.Black;
            this.txtLoginEmail.Location = new System.Drawing.Point(15, 307);
            this.txtLoginEmail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtLoginEmail.Name = "txtLoginEmail";
            this.txtLoginEmail.Size = new System.Drawing.Size(422, 38);
            this.txtLoginEmail.TabIndex = 7;
            this.txtLoginEmail.Tag = "";
            // 
            // btnShowPassowrdLogin
            // 
            this.btnShowPassowrdLogin.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnShowPassowrdLogin.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnShowPassowrdLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnShowPassowrdLogin.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnShowPassowrdLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowPassowrdLogin.ForeColor = System.Drawing.Color.Black;
            this.btnShowPassowrdLogin.Location = new System.Drawing.Point(16, 434);
            this.btnShowPassowrdLogin.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.btnShowPassowrdLogin.Name = "btnShowPassowrdLogin";
            this.btnShowPassowrdLogin.Size = new System.Drawing.Size(93, 43);
            this.btnShowPassowrdLogin.TabIndex = 40;
            this.btnShowPassowrdLogin.Text = "Show";
            this.btnShowPassowrdLogin.UseVisualStyleBackColor = false;
            // 
            // btnLogin
            // 
            this.btnLogin.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnLogin.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.ForeColor = System.Drawing.Color.Black;
            this.btnLogin.Location = new System.Drawing.Point(334, 434);
            this.btnLogin.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(103, 43);
            this.btnLogin.TabIndex = 39;
            this.btnLogin.Text = "Login";
            this.btnLogin.UseVisualStyleBackColor = false;
            // 
            // lblSignUpNewLogin
            // 
            this.lblSignUpNewLogin.AutoSize = true;
            this.lblSignUpNewLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblSignUpNewLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSignUpNewLogin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblSignUpNewLogin.Location = new System.Drawing.Point(281, 521);
            this.lblSignUpNewLogin.Name = "lblSignUpNewLogin";
            this.lblSignUpNewLogin.Size = new System.Drawing.Size(130, 25);
            this.lblSignUpNewLogin.TabIndex = 42;
            this.lblSignUpNewLogin.Text = "Sign up now";
            // 
            // lblDontHaveAccount2Login
            // 
            this.lblDontHaveAccount2Login.AutoSize = true;
            this.lblDontHaveAccount2Login.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDontHaveAccount2Login.ForeColor = System.Drawing.Color.Black;
            this.lblDontHaveAccount2Login.Location = new System.Drawing.Point(46, 521);
            this.lblDontHaveAccount2Login.Name = "lblDontHaveAccount2Login";
            this.lblDontHaveAccount2Login.Size = new System.Drawing.Size(241, 25);
            this.lblDontHaveAccount2Login.TabIndex = 41;
            this.lblDontHaveAccount2Login.Text = "Don\'t Have an account?";
            // 
            // TempLoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(1022, 586);
            this.Controls.Add(this.panel1);
            this.Name = "TempLoginForm";
            this.Text = "TempLoginForm";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picboxBankLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblIntroLoginPage;
        private System.Windows.Forms.Label lblUserLogin;
        private System.Windows.Forms.PictureBox picboxBankLogo;
        private System.Windows.Forms.Label lblLoginPassword;
        private System.Windows.Forms.TextBox txtLoginPassword;
        private System.Windows.Forms.Label lblLoginEmail;
        private System.Windows.Forms.TextBox txtLoginEmail;
        private System.Windows.Forms.Button btnShowPassowrdLogin;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label lblSignUpNewLogin;
        private System.Windows.Forms.Label lblDontHaveAccount2Login;
    }
}