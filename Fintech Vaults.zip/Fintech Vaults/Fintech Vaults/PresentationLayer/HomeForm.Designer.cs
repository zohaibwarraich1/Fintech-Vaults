﻿
using System;

namespace Fintech_Vaults.PresentationLayer
{
    partial class HomeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuHome = new System.Windows.Forms.Panel();
            this.btnLogoutHomeForm = new System.Windows.Forms.Button();
            this.btnSettingsMenuHomeForm = new System.Windows.Forms.Button();
            this.btnPolicyHomeForm = new System.Windows.Forms.Button();
            this.btnChargesScheduleHomeForm = new System.Windows.Forms.Button();
            this.btnManageCardMenuHomeForm = new System.Windows.Forms.Button();
            this.btnTransactionHistoryHomeForm = new System.Windows.Forms.Button();
            this.btnHomeForm = new System.Windows.Forms.Button();
            this.btnAccountDetailsHomeForm = new System.Windows.Forms.Button();
            this.picboxBankLogo = new System.Windows.Forms.PictureBox();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.lblBalanceHomeForm = new System.Windows.Forms.Label();
            this.btnShowBalance2HomeForm = new System.Windows.Forms.Button();
            this.txtBalanceHomeForm = new System.Windows.Forms.TextBox();
            this.btnSettingsHomeForm = new System.Windows.Forms.Button();
            this.btnManageCardHomeForm = new System.Windows.Forms.Button();
            this.btnDepositHomeForm = new System.Windows.Forms.Button();
            this.btnSendMoneyHomeForm = new System.Windows.Forms.Button();
            this.menuHome.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picboxBankLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // menuHome
            // 
            this.menuHome.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.menuHome.Controls.Add(this.btnLogoutHomeForm);
            this.menuHome.Controls.Add(this.btnSettingsMenuHomeForm);
            this.menuHome.Controls.Add(this.btnPolicyHomeForm);
            this.menuHome.Controls.Add(this.btnChargesScheduleHomeForm);
            this.menuHome.Controls.Add(this.btnManageCardMenuHomeForm);
            this.menuHome.Controls.Add(this.btnTransactionHistoryHomeForm);
            this.menuHome.Controls.Add(this.btnHomeForm);
            this.menuHome.Controls.Add(this.btnAccountDetailsHomeForm);
            this.menuHome.Controls.Add(this.picboxBankLogo);
            this.menuHome.Location = new System.Drawing.Point(-12, -24);
            this.menuHome.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.menuHome.Name = "menuHome";
            this.menuHome.Size = new System.Drawing.Size(197, 732);
            this.menuHome.TabIndex = 0;
            // 
            // btnLogoutHomeForm
            // 
            this.btnLogoutHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLogoutHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_logout_30;
            this.btnLogoutHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnLogoutHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogoutHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLogoutHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogoutHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnLogoutHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnLogoutHomeForm.Location = new System.Drawing.Point(23, 558);
            this.btnLogoutHomeForm.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnLogoutHomeForm.Name = "btnLogoutHomeForm";
            this.btnLogoutHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnLogoutHomeForm.Size = new System.Drawing.Size(158, 33);
            this.btnLogoutHomeForm.TabIndex = 8;
            this.btnLogoutHomeForm.Text = "Logout";
            this.btnLogoutHomeForm.UseVisualStyleBackColor = false;
            this.btnLogoutHomeForm.Click += new System.EventHandler(this.btnLogoutHomeForm_Click);
            // 
            // btnSettingsMenuHomeForm
            // 
            this.btnSettingsMenuHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnSettingsMenuHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_setting_30;
            this.btnSettingsMenuHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSettingsMenuHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSettingsMenuHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSettingsMenuHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettingsMenuHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnSettingsMenuHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnSettingsMenuHomeForm.Location = new System.Drawing.Point(23, 505);
            this.btnSettingsMenuHomeForm.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSettingsMenuHomeForm.Name = "btnSettingsMenuHomeForm";
            this.btnSettingsMenuHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnSettingsMenuHomeForm.Size = new System.Drawing.Size(158, 32);
            this.btnSettingsMenuHomeForm.TabIndex = 7;
            this.btnSettingsMenuHomeForm.Text = "Settings";
            this.btnSettingsMenuHomeForm.UseVisualStyleBackColor = false;
            this.btnSettingsMenuHomeForm.Click += new System.EventHandler(this.btnSettingsMenuHomeForm_Click);
            // 
            // btnPolicyHomeForm
            // 
            this.btnPolicyHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnPolicyHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_policy_30;
            this.btnPolicyHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnPolicyHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPolicyHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPolicyHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPolicyHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnPolicyHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnPolicyHomeForm.Location = new System.Drawing.Point(23, 451);
            this.btnPolicyHomeForm.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnPolicyHomeForm.Name = "btnPolicyHomeForm";
            this.btnPolicyHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnPolicyHomeForm.Size = new System.Drawing.Size(158, 34);
            this.btnPolicyHomeForm.TabIndex = 6;
            this.btnPolicyHomeForm.Text = "Policy";
            this.btnPolicyHomeForm.UseVisualStyleBackColor = false;
            this.btnPolicyHomeForm.Click += new System.EventHandler(this.btnPolicyHomeForm_Click);
            // 
            // btnChargesScheduleHomeForm
            // 
            this.btnChargesScheduleHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnChargesScheduleHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_pay_wall_50;
            this.btnChargesScheduleHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnChargesScheduleHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChargesScheduleHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnChargesScheduleHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChargesScheduleHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnChargesScheduleHomeForm.Location = new System.Drawing.Point(23, 381);
            this.btnChargesScheduleHomeForm.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnChargesScheduleHomeForm.Name = "btnChargesScheduleHomeForm";
            this.btnChargesScheduleHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnChargesScheduleHomeForm.Size = new System.Drawing.Size(158, 53);
            this.btnChargesScheduleHomeForm.TabIndex = 5;
            this.btnChargesScheduleHomeForm.Text = "Charges Schedule";
            this.btnChargesScheduleHomeForm.UseVisualStyleBackColor = false;
            this.btnChargesScheduleHomeForm.Click += new System.EventHandler(this.btnChargesScheduleHomeForm_Click);
            // 
            // btnManageCardMenuHomeForm
            // 
            this.btnManageCardMenuHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnManageCardMenuHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_card_30__1_;
            this.btnManageCardMenuHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnManageCardMenuHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnManageCardMenuHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnManageCardMenuHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManageCardMenuHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnManageCardMenuHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnManageCardMenuHomeForm.Location = new System.Drawing.Point(23, 327);
            this.btnManageCardMenuHomeForm.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnManageCardMenuHomeForm.Name = "btnManageCardMenuHomeForm";
            this.btnManageCardMenuHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnManageCardMenuHomeForm.Size = new System.Drawing.Size(158, 30);
            this.btnManageCardMenuHomeForm.TabIndex = 4;
            this.btnManageCardMenuHomeForm.Text = "Manage Card";
            this.btnManageCardMenuHomeForm.UseVisualStyleBackColor = false;
            this.btnManageCardMenuHomeForm.Click += new System.EventHandler(this.btnManageCardMenuHomeForm_Click);
            // 
            // btnTransactionHistoryHomeForm
            // 
            this.btnTransactionHistoryHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnTransactionHistoryHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_transaction_501;
            this.btnTransactionHistoryHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnTransactionHistoryHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTransactionHistoryHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTransactionHistoryHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTransactionHistoryHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnTransactionHistoryHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnTransactionHistoryHomeForm.Location = new System.Drawing.Point(23, 254);
            this.btnTransactionHistoryHomeForm.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnTransactionHistoryHomeForm.Name = "btnTransactionHistoryHomeForm";
            this.btnTransactionHistoryHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnTransactionHistoryHomeForm.Size = new System.Drawing.Size(158, 52);
            this.btnTransactionHistoryHomeForm.TabIndex = 3;
            this.btnTransactionHistoryHomeForm.Text = "Transaction History";
            this.btnTransactionHistoryHomeForm.UseVisualStyleBackColor = false;
            this.btnTransactionHistoryHomeForm.Click += new System.EventHandler(this.btnTransactionHistoryHomeForm_Click);
            // 
            // btnHomeForm
            // 
            this.btnHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_home_30;
            this.btnHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnHomeForm.Location = new System.Drawing.Point(23, 203);
            this.btnHomeForm.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnHomeForm.Name = "btnHomeForm";
            this.btnHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnHomeForm.Size = new System.Drawing.Size(158, 31);
            this.btnHomeForm.TabIndex = 2;
            this.btnHomeForm.Text = "Home";
            this.btnHomeForm.UseVisualStyleBackColor = false;
            // 
            // btnAccountDetailsHomeForm
            // 
            this.btnAccountDetailsHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnAccountDetailsHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_account_30;
            this.btnAccountDetailsHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnAccountDetailsHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAccountDetailsHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAccountDetailsHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAccountDetailsHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnAccountDetailsHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnAccountDetailsHomeForm.Location = new System.Drawing.Point(23, 154);
            this.btnAccountDetailsHomeForm.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAccountDetailsHomeForm.Name = "btnAccountDetailsHomeForm";
            this.btnAccountDetailsHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnAccountDetailsHomeForm.Size = new System.Drawing.Size(158, 31);
            this.btnAccountDetailsHomeForm.TabIndex = 1;
            this.btnAccountDetailsHomeForm.Text = "Account Details";
            this.btnAccountDetailsHomeForm.UseVisualStyleBackColor = false;
            this.btnAccountDetailsHomeForm.Click += new System.EventHandler(this.btnAccountDetailsHomeForm_Click);
            // 
            // picboxBankLogo
            // 
            this.picboxBankLogo.Image = global::Fintech_Vaults.Properties.Resources.attachment_62465982_removebg_preview;
            this.picboxBankLogo.Location = new System.Drawing.Point(0, 21);
            this.picboxBankLogo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.picboxBankLogo.Name = "picboxBankLogo";
            this.picboxBankLogo.Size = new System.Drawing.Size(221, 119);
            this.picboxBankLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picboxBankLogo.TabIndex = 0;
            this.picboxBankLogo.TabStop = false;
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            // 
            // lblBalanceHomeForm
            // 
            this.lblBalanceHomeForm.AutoSize = true;
            this.lblBalanceHomeForm.Font = new System.Drawing.Font("Microsoft Tai Le", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalanceHomeForm.Location = new System.Drawing.Point(497, 71);
            this.lblBalanceHomeForm.Name = "lblBalanceHomeForm";
            this.lblBalanceHomeForm.Size = new System.Drawing.Size(181, 34);
            this.lblBalanceHomeForm.TabIndex = 2;
            this.lblBalanceHomeForm.Text = "Your Balance";
            this.lblBalanceHomeForm.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnShowBalance2HomeForm
            // 
            this.btnShowBalance2HomeForm.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnShowBalance2HomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnShowBalance2HomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnShowBalance2HomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnShowBalance2HomeForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowBalance2HomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnShowBalance2HomeForm.Location = new System.Drawing.Point(738, 118);
            this.btnShowBalance2HomeForm.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.btnShowBalance2HomeForm.Name = "btnShowBalance2HomeForm";
            this.btnShowBalance2HomeForm.Size = new System.Drawing.Size(93, 43);
            this.btnShowBalance2HomeForm.TabIndex = 42;
            this.btnShowBalance2HomeForm.Text = "Show";
            this.btnShowBalance2HomeForm.UseVisualStyleBackColor = false;
            this.btnShowBalance2HomeForm.Click += new System.EventHandler(this.btnShowBalance2HomeForm_Click);
            // 
            // txtBalanceHomeForm
            // 
            this.txtBalanceHomeForm.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBalanceHomeForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBalanceHomeForm.Location = new System.Drawing.Point(461, 126);
            this.txtBalanceHomeForm.Name = "txtBalanceHomeForm";
            this.txtBalanceHomeForm.ReadOnly = true;
            this.txtBalanceHomeForm.Size = new System.Drawing.Size(236, 31);
            this.txtBalanceHomeForm.TabIndex = 43;
            this.txtBalanceHomeForm.TextChanged += new System.EventHandler(this.txtBalanceHomeForm_TextChanged_1);
            // 
            // btnSettingsHomeForm
            // 
            this.btnSettingsHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnSettingsHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSettingsHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSettingsHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSettingsHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettingsHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnSettingsHomeForm.Image = global::Fintech_Vaults.Properties.Resources.icons8_settings_50;
            this.btnSettingsHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnSettingsHomeForm.Location = new System.Drawing.Point(475, 458);
            this.btnSettingsHomeForm.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSettingsHomeForm.Name = "btnSettingsHomeForm";
            this.btnSettingsHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnSettingsHomeForm.Size = new System.Drawing.Size(241, 55);
            this.btnSettingsHomeForm.TabIndex = 40;
            this.btnSettingsHomeForm.Text = "Settings";
            this.btnSettingsHomeForm.UseVisualStyleBackColor = false;
            this.btnSettingsHomeForm.Click += new System.EventHandler(this.btnSettingsHomeForm_Click);
            // 
            // btnManageCardHomeForm
            // 
            this.btnManageCardHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnManageCardHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnManageCardHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnManageCardHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManageCardHomeForm.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManageCardHomeForm.Image = global::Fintech_Vaults.Properties.Resources.icons8_credit_card_641;
            this.btnManageCardHomeForm.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnManageCardHomeForm.Location = new System.Drawing.Point(779, 227);
            this.btnManageCardHomeForm.Name = "btnManageCardHomeForm";
            this.btnManageCardHomeForm.Padding = new System.Windows.Forms.Padding(0, 0, 0, 19);
            this.btnManageCardHomeForm.Size = new System.Drawing.Size(133, 173);
            this.btnManageCardHomeForm.TabIndex = 5;
            this.btnManageCardHomeForm.Text = "Manage Credit\r\nCard and see\r\ndetail";
            this.btnManageCardHomeForm.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnManageCardHomeForm.UseCompatibleTextRendering = true;
            this.btnManageCardHomeForm.UseMnemonic = false;
            this.btnManageCardHomeForm.UseVisualStyleBackColor = false;
            this.btnManageCardHomeForm.Click += new System.EventHandler(this.btnManageCardHomeForm_Click);
            // 
            // btnDepositHomeForm
            // 
            this.btnDepositHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnDepositHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDepositHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDepositHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDepositHomeForm.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDepositHomeForm.Image = global::Fintech_Vaults.Properties.Resources.icons8_deposit_64;
            this.btnDepositHomeForm.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnDepositHomeForm.Location = new System.Drawing.Point(530, 227);
            this.btnDepositHomeForm.Name = "btnDepositHomeForm";
            this.btnDepositHomeForm.Padding = new System.Windows.Forms.Padding(0, 0, 0, 4);
            this.btnDepositHomeForm.Size = new System.Drawing.Size(133, 173);
            this.btnDepositHomeForm.TabIndex = 4;
            this.btnDepositHomeForm.Text = "Deposit Money/\r\nFunds into\r\nYour Account\r\nSafely";
            this.btnDepositHomeForm.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDepositHomeForm.UseCompatibleTextRendering = true;
            this.btnDepositHomeForm.UseMnemonic = false;
            this.btnDepositHomeForm.UseVisualStyleBackColor = false;
            this.btnDepositHomeForm.Click += new System.EventHandler(this.btnDepositHomeForm_Click);
            // 
            // btnSendMoneyHomeForm
            // 
            this.btnSendMoneyHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnSendMoneyHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSendMoneyHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSendMoneyHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSendMoneyHomeForm.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSendMoneyHomeForm.Image = global::Fintech_Vaults.Properties.Resources.icons8_transfer_money_60;
            this.btnSendMoneyHomeForm.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnSendMoneyHomeForm.Location = new System.Drawing.Point(281, 227);
            this.btnSendMoneyHomeForm.Name = "btnSendMoneyHomeForm";
            this.btnSendMoneyHomeForm.Padding = new System.Windows.Forms.Padding(0, 0, 0, 4);
            this.btnSendMoneyHomeForm.Size = new System.Drawing.Size(133, 173);
            this.btnSendMoneyHomeForm.TabIndex = 1;
            this.btnSendMoneyHomeForm.Text = "Send Money/\r\nTransfer Funds to\r\nany Account ";
            this.btnSendMoneyHomeForm.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSendMoneyHomeForm.UseCompatibleTextRendering = true;
            this.btnSendMoneyHomeForm.UseMnemonic = false;
            this.btnSendMoneyHomeForm.UseVisualStyleBackColor = false;
            this.btnSendMoneyHomeForm.Click += new System.EventHandler(this.btnSendMoneyHomeForm_Click);
            // 
            // HomeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(1022, 586);
            this.Controls.Add(this.txtBalanceHomeForm);
            this.Controls.Add(this.btnShowBalance2HomeForm);
            this.Controls.Add(this.btnSettingsHomeForm);
            this.Controls.Add(this.btnManageCardHomeForm);
            this.Controls.Add(this.btnDepositHomeForm);
            this.Controls.Add(this.lblBalanceHomeForm);
            this.Controls.Add(this.btnSendMoneyHomeForm);
            this.Controls.Add(this.menuHome);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "HomeForm";
            this.Text = "HomeForm";
            this.Load += new System.EventHandler(this.HomeForm_Load);
            this.menuHome.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picboxBankLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void txtBalanceHomeForm_TextChanged(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void btnShowPassowrdLogin_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }



        #endregion

        private System.Windows.Forms.Panel menuHome;
        private System.Windows.Forms.PictureBox picboxBankLogo;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.Button btnAccountDetailsHomeForm;
        private System.Windows.Forms.Button btnLogoutHomeForm;
        private System.Windows.Forms.Button btnSettingsMenuHomeForm;
        private System.Windows.Forms.Button btnPolicyHomeForm;
        private System.Windows.Forms.Button btnChargesScheduleHomeForm;
        private System.Windows.Forms.Button btnManageCardMenuHomeForm;
        private System.Windows.Forms.Button btnTransactionHistoryHomeForm;
        private System.Windows.Forms.Button btnHomeForm;
        private System.Windows.Forms.Label lblBalanceHomeForm;
        private System.Windows.Forms.Button btnSendMoneyHomeForm;
        private System.Windows.Forms.Button btnDepositHomeForm;
        private System.Windows.Forms.Button btnManageCardHomeForm;
        private System.Windows.Forms.Button btnSettingsHomeForm;
        private System.Windows.Forms.Button btnShowBalance2HomeForm;
        private System.Windows.Forms.TextBox txtBalanceHomeForm;
    }
}