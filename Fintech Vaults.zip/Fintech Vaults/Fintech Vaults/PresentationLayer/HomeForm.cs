﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Fintech_Vaults.BusinessLayer;
using Fintech_Vaults.DataLayer;
namespace Fintech_Vaults.PresentationLayer
{
    public partial class HomeForm : Form
    {
        Account acc = new Account();
        public HomeForm()
        {
            InitializeComponent();
        }
        private void HomeForm_Load(object sender, EventArgs e)
        {
            acc.Balance = DBConnection.ShowBalanceHomePage();
            btnShowBalance2HomeForm.Text = "Show";
            txtBalanceHomeForm.Text = "******";
        }

        private void notifyIcon2_MouseDoubleClick(object sender, MouseEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
        }


        private void btnShowBalance2HomeForm_Click(object sender, EventArgs e)
        {
            if (btnShowBalance2HomeForm.Text == "Show")
            {
                txtBalanceHomeForm.Text = "Rs. " + acc.Balance;
                btnShowBalance2HomeForm.Text = "Hide";
            }
            else
            {
                txtBalanceHomeForm.Text = "******";
                btnShowBalance2HomeForm.Text = "Show";
            }
        }

        private void txtBalanceHomeForm_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void btnSettingsHomeForm_Click(object sender, EventArgs e)
        {
            Settings s1 = new Settings();
            this.Hide();
            s1.Show();
        }

        private void btnDepositHomeForm_Click(object sender, EventArgs e)
        {
            DepositMoney dm1 = new DepositMoney();
            this.Hide();
            dm1.Show();
        }

        private void btnAccountDetailsHomeForm_Click(object sender, EventArgs e)
        {
            AccountForm af1 = new AccountForm();
            this.Hide();
            af1.Show();
        }

        private void btnSendMoneyHomeForm_Click(object sender, EventArgs e)
        {
            SendMoney sm1 = new SendMoney();
            sm1.Show();
            this.Hide();
        }

        private void btnLogoutHomeForm_Click(object sender, EventArgs e)
        {
            LoginForm lf1 = new LoginForm();
            lf1.Show();
            this.Hide();
        }

        private void btnSettingsMenuHomeForm_Click(object sender, EventArgs e)
        {
            Settings set = new Settings();
            set.Show();
            this.Hide();
        }

        private void btnPolicyHomeForm_Click(object sender, EventArgs e)
        {
            Policy p = new Policy();
            p.Show();
            this.Hide();
        }

        private void btnChargesScheduleHomeForm_Click(object sender, EventArgs e)
        {
            Charges ch = new Charges();
            ch.Show();
            this.Hide();
        }

        private void btnTransactionHistoryHomeForm_Click(object sender, EventArgs e)
        {
            TransactionHistory t = new TransactionHistory();
            t.Show();
            this.Hide();
        }

        private void btnManageCardMenuHomeForm_Click(object sender, EventArgs e)
        {
            CreditCardForm c = new CreditCardForm();
            c.Show();
            this.Hide();
        }

        private void btnManageCardHomeForm_Click(object sender, EventArgs e)
        {
            CreditCardForm c = new CreditCardForm();
            this.Hide();
            c.Show();
        }
    }
}
