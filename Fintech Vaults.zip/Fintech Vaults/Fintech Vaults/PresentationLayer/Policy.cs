﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Fintech_Vaults.BusinessLayer;
using Fintech_Vaults.DataLayer;
namespace Fintech_Vaults.PresentationLayer
{
    public partial class Policy : Form
    {

        public Policy()
        {
            InitializeComponent();
        }
        private void Policy_Load(object sender, EventArgs e)
        {
            dgvPolicy.BorderStyle = BorderStyle.None;
            dgvPolicy.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(238, 239, 249);
            dgvPolicy.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvPolicy.DefaultCellStyle.SelectionBackColor = Color.DarkTurquoise;
            dgvPolicy.DefaultCellStyle.SelectionForeColor = Color.WhiteSmoke;
            dgvPolicy.BackgroundColor = Color.White;

            dgvPolicy.EnableHeadersVisualStyles = false;
            dgvPolicy.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(20, 25, 72);
            dgvPolicy.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            SqlDataReader reader = DBConnection.Policies();
            while (reader.Read())
            {
                BusinessLayer.Policy p1 = new BusinessLayer.Policy();
                p1.PolicyID = int.Parse(reader["PolicyID"].ToString());
                p1.PolicyText = reader["PolicyText"].ToString();
                dgvPolicy.Rows.Add(p1.PolicyID, p1.PolicyText);
            }
        }

        private void dgvPolicy_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnSettingsMenuHomeForm_Click(object sender, EventArgs e)
        {
            Settings s1 = new Settings();
            this.Hide();
            s1.Show();
        }

        private void btnLogoutHomeForm_Click(object sender, EventArgs e)
        {
            LoginForm lf1 = new LoginForm();
            lf1.Show();
            this.Hide();
        }

        private void btnHomeForm_Click(object sender, EventArgs e)
        {
            HomeForm hf1 = new HomeForm();
            hf1.Show();
            this.Hide();
        }

        private void btnTransactionHistoryHomeForm_Click(object sender, EventArgs e)
        {
            TransactionHistory t = new TransactionHistory();
            t.Show();
            this.Hide();
        }

        private void btnAccountDetailsHomeForm_Click(object sender, EventArgs e)
        {
            AccountForm acc = new AccountForm();
            acc.Show();
            this.Hide();
        }

        private void btnChargesScheduleHomeForm_Click(object sender, EventArgs e)
        {
            Charges ch = new Charges();
            ch.Show();
            this.Hide();
        }

        private void btnBackPolicyForm_Click(object sender, EventArgs e)
        {
            Charges ch = new Charges();
            ch.Show();
            this.Hide();
        }

        private void btnNextPolicy_Click(object sender, EventArgs e)
        {
            Settings s1 = new Settings();
            this.Hide();
            s1.Show();
        }

        private void btnManageCardMenuHomeForm_Click(object sender, EventArgs e)
        {
            CreditCardForm c = new CreditCardForm();
            c.Show();
            this.Hide();
        }
    }
}
