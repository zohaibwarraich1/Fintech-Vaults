﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Fintech_Vaults.BusinessLayer;
using Fintech_Vaults.DataLayer;
namespace Fintech_Vaults.PresentationLayer
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        private void lblSignUpNewLogin_Click(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click_2(object sender, EventArgs e)
        {

        }

        private void btnShowPassowrdSignUp_Click(object sender, EventArgs e)
        {

        }

        private void txtLoginPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblIntroLoginPage_Click(object sender, EventArgs e)
        {

        }

        private void lblLoginEmail_Click(object sender, EventArgs e)
        {

        }

        private void txtLoginEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblLoginPassword_Click(object sender, EventArgs e)
        {

        }

        private void lblDontHaveAccount2Login_Click(object sender, EventArgs e)
        {

        }

        private void picboxLogin_Click(object sender, EventArgs e)
        {

        }

        private void btnShowPassowrdLogin_Click(object sender, EventArgs e)
        {
            if (btnShowPassowrdLogin.Text == "Hide")
            {
                txtLoginPassword.UseSystemPasswordChar = true;
                btnShowPassowrdLogin.Text = "Show";
            }
            else
            {
                txtLoginPassword.UseSystemPasswordChar = false;
                btnShowPassowrdLogin.Text = "Hide";
            }
        }

        private void btnLogin_Click_3(object sender, EventArgs e)
        {
            string loginEmail = txtLoginEmail.Text;
            string loginPass = txtLoginPassword.Text;
            User usr1 = new User();
            DBConnection.LoginID(usr1, loginEmail, loginPass);
            if (usr1.Email == loginEmail && usr1.Password == loginPass)
            {
                DBConnection.NecessaryStaticDetails(loginEmail, loginPass);
                MessageBox.Show("You have successfully Logged In.", "Logged In", MessageBoxButtons.OK, MessageBoxIcon.Information);
                HomeForm homeform1 = new HomeForm();
                homeform1.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("You have entered wrong email or password.\nPlease enter correct information.", "Invalid Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtLoginEmail.Clear();
                txtLoginPassword.Clear();
            }
        }

        private void lblSignUpNewLogin_Click_1(object sender, EventArgs e)
        {
            Signup signupAccount = new Signup();
            signupAccount.Show();
            this.Hide();
            txtLoginEmail.Clear();
            txtLoginPassword.Clear();
        }
    }
}
