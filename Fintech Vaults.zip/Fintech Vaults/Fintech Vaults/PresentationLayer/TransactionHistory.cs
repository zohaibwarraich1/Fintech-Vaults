﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Fintech_Vaults.BusinessLayer;
using Fintech_Vaults.DataLayer;
namespace Fintech_Vaults.PresentationLayer
{
    public partial class TransactionHistory : Form
    {
        public TransactionHistory()
        {
            InitializeComponent();
        }

        private void TransactionHistory_Load(object sender, EventArgs e)
        {
            dgvTransactionHistory.BorderStyle = BorderStyle.None;
            dgvTransactionHistory.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(238, 239, 249);
            dgvTransactionHistory.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvTransactionHistory.DefaultCellStyle.SelectionBackColor = Color.DarkTurquoise;
            dgvTransactionHistory.DefaultCellStyle.SelectionForeColor = Color.WhiteSmoke;
            dgvTransactionHistory.BackgroundColor = Color.White;

            dgvTransactionHistory.EnableHeadersVisualStyles = false;
            dgvTransactionHistory.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(20, 25, 72);
            dgvTransactionHistory.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            SqlDataReader reader = DBConnection.TransactionHistory();
            while (reader.Read())
            {
                Transaction t1 = new Transaction();
                t1.BeneficiaryID = int.Parse(reader["BeneficiaryID"].ToString());
                t1.Time = reader["TimeStamp"].ToString();
                t1.Amount = int.Parse(reader["Amount"].ToString());
                t1.TransactionType = reader["TransactionType"].ToString();
                dgvTransactionHistory.Rows.Add(t1.BeneficiaryID, t1.Time, t1.Amount, t1.TransactionType);
            }
        }

        private void btnTransactionHistoryHomeForm_Click(object sender, EventArgs e)
        {

        }

        private void btnBackPolicyForm_Click(object sender, EventArgs e)
        {
            HomeForm h = new HomeForm();
            h.Show();
            this.Hide();
        }

        private void btnAccountDetailsHomeForm_Click(object sender, EventArgs e)
        {
            AccountForm a = new AccountForm();
            a.Show();
            this.Hide();
        }

        private void btnHomeForm_Click(object sender, EventArgs e)
        {
            HomeForm h = new HomeForm();
            h.Show();
            this.Hide();

        }

        private void btnChargesScheduleHomeForm_Click(object sender, EventArgs e)
        {
            Charges c = new Charges();
            c.Show();
            this.Hide();
        }

        private void btnPolicyHomeForm_Click(object sender, EventArgs e)
        {
            Policy p = new Policy();
            p.Show();
            this.Hide();
        }

        private void btnSettingsMenuHomeForm_Click(object sender, EventArgs e)
        {
            Settings s = new Settings();
            this.Hide();
            s.Show();

        }

        private void btnLogoutHomeForm_Click(object sender, EventArgs e)
        {
            LoginForm l = new LoginForm();
            l.Show();
            this.Hide();
        }

        private void btnManageCardMenuHomeForm_Click(object sender, EventArgs e)
        {
            CreditCardForm c = new CreditCardForm();
            c.Show();
            this.Hide();
        }

        private void btnNextPolicy_Click(object sender, EventArgs e)
        {
            CreditCardForm c = new CreditCardForm();
            c.Show();
            this.Hide();
        }
    }
}
