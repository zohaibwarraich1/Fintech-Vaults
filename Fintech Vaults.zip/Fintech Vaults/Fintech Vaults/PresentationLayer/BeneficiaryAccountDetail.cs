﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Fintech_Vaults.BusinessLayer;
using Fintech_Vaults.DataLayer;
namespace Fintech_Vaults.PresentationLayer
{
    public partial class BeneficiaryAccountDetail : Form
    {
        Transaction beneficiary = new Transaction();
        public BeneficiaryAccountDetail()
        {
            InitializeComponent();
        }
        public BeneficiaryAccountDetail(int amount, int accountid)
        {
            InitializeComponent();
            beneficiary.AccountID = accountid;
            beneficiary.Amount = amount;
        }
        private void btnConfirmPaymentBAD_Click(object sender, EventArgs e)
        {
            User usr1 = new User();
            User usr2 = new User();
            Account acc1 = new Account();
            Account acc2 = new Account();
            BusinessLayer.Charges c1 = new BusinessLayer.Charges();
            c1.ChargeID = -1;
            DBConnection.ChargesDeductionFromTransferedAmount(beneficiary, c1);
            Transaction Sender = new Transaction(Account.AccountID, beneficiary.AccountID, c1.ChargeID, "Debited", beneficiary.Amount, DateTime.Now.ToString());
            DBConnection.InsertTransactionDetails(Sender);
            Transaction Reciever = new Transaction(beneficiary.AccountID, Account.AccountID, c1.ChargeID, "Debited", beneficiary.Amount, DateTime.Now.ToString());
            DBConnection.InsertTransactionDetails(Reciever);
            Transaction temp = new Transaction();
            temp.AccountID = Account.AccountID;
            temp.Amount = beneficiary.Amount;
            DBConnection.UpdatebalanceAfterTransaction(temp, "Debited");
            DBConnection.UpdatebalanceAfterTransaction(beneficiary, "Credited");
            MessageBox.Show("Amount has been successfully transfered!", "Successfull Transaction", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            acc1.Transaction = Sender;
            acc1.Charges = c1;
            acc2.Transaction = Reciever;
            acc2.Charges = c1;
            usr1.TheAccount = acc1;
            usr2.TheAccount = acc2;
            SendMoney sm = new SendMoney();
            sm.Show();
            this.Hide();
        }

        private void BeneficiaryAccountDetail_Load(object sender, EventArgs e)
        {
            User usr1 = new User();
            int refAccountID = 0;
            DBConnection.MoneyTransferBeneficiaryDetails(beneficiary.AccountID, ref refAccountID, usr1);
            txtBeneficiaryAccountIDBAD.Text = beneficiary.AccountID.ToString();
            txtBeneficiaryMobileNoBAD.Text = usr1.MobileNo.ToString();
            txtBeneficiaryNameBAD.Text = usr1.FullName.ToString();
        }

        private void txtBeneficiaryAccountBAD_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAccountDetailsHomeForm_Click(object sender, EventArgs e)
        {
            AccountForm af1 = new AccountForm();
            af1.Show();
            this.Hide();
        }

        private void btnHomeForm_Click(object sender, EventArgs e)
        {
            HomeForm hf1 = new HomeForm();
            hf1.Show();
            this.Hide();
        }

        private void btnLogoutHomeForm_Click(object sender, EventArgs e)
        {
            LoginForm lf1 = new LoginForm();
            lf1.Show();
            this.Hide();
        }

        private void btnBackBAD_Click(object sender, EventArgs e)
        {
            SendMoney sm1 = new SendMoney();
            sm1.Show();
            this.Hide();
        }

        private void btnSettingsMenuHomeForm_Click(object sender, EventArgs e)
        {
            Settings s1 = new Settings();
            this.Hide();
            s1.Show();
        }

        private void btnPolicyHomeForm_Click(object sender, EventArgs e)
        {
            Policy p = new Policy();
            p.Show();
            this.Hide();
        }

        private void btnChargesScheduleHomeForm_Click(object sender, EventArgs e)
        {
            Charges ch = new Charges();
            ch.Show();
            this.Hide();
        }

        private void btnTransactionHistoryHomeForm_Click(object sender, EventArgs e)
        {
            TransactionHistory t = new TransactionHistory();
            t.Show();
            this.Hide();
        }

        private void btnManageCardMenuHomeForm_Click(object sender, EventArgs e)
        {
            CreditCardForm c = new CreditCardForm();
            c.Show();
            this.Hide();
        }
    }
}
