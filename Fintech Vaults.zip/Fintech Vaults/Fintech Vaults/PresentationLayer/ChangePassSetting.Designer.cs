﻿
namespace Fintech_Vaults.PresentationLayer
{
    partial class btnChangePassCPS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuHome = new System.Windows.Forms.Panel();
            this.btnLogoutHomeForm = new System.Windows.Forms.Button();
            this.btnSettingsMenuHomeForm = new System.Windows.Forms.Button();
            this.btnPolicyHomeForm = new System.Windows.Forms.Button();
            this.btnChargesScheduleHomeForm = new System.Windows.Forms.Button();
            this.btnManageCardMenuHomeForm = new System.Windows.Forms.Button();
            this.btnTransactionHistoryHomeForm = new System.Windows.Forms.Button();
            this.btnHomeForm = new System.Windows.Forms.Button();
            this.btnAccountDetailsHomeForm = new System.Windows.Forms.Button();
            this.picboxBankLogo = new System.Windows.Forms.PictureBox();
            this.txtOldPassCPS = new System.Windows.Forms.TextBox();
            this.lblOldPass = new System.Windows.Forms.Label();
            this.lblMoneyTransferBAD = new System.Windows.Forms.Label();
            this.txtNewPassCPS = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtConfirmNewPassCPS = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnConfirmPassSetting = new System.Windows.Forms.Button();
            this.menuHome.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picboxBankLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // menuHome
            // 
            this.menuHome.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.menuHome.Controls.Add(this.btnLogoutHomeForm);
            this.menuHome.Controls.Add(this.btnSettingsMenuHomeForm);
            this.menuHome.Controls.Add(this.btnPolicyHomeForm);
            this.menuHome.Controls.Add(this.btnChargesScheduleHomeForm);
            this.menuHome.Controls.Add(this.btnManageCardMenuHomeForm);
            this.menuHome.Controls.Add(this.btnTransactionHistoryHomeForm);
            this.menuHome.Controls.Add(this.btnHomeForm);
            this.menuHome.Controls.Add(this.btnAccountDetailsHomeForm);
            this.menuHome.Controls.Add(this.picboxBankLogo);
            this.menuHome.Location = new System.Drawing.Point(-12, -24);
            this.menuHome.Margin = new System.Windows.Forms.Padding(2);
            this.menuHome.Name = "menuHome";
            this.menuHome.Size = new System.Drawing.Size(197, 732);
            this.menuHome.TabIndex = 4;
            // 
            // btnLogoutHomeForm
            // 
            this.btnLogoutHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnLogoutHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_logout_30;
            this.btnLogoutHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnLogoutHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogoutHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLogoutHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogoutHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnLogoutHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnLogoutHomeForm.Location = new System.Drawing.Point(23, 558);
            this.btnLogoutHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnLogoutHomeForm.Name = "btnLogoutHomeForm";
            this.btnLogoutHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnLogoutHomeForm.Size = new System.Drawing.Size(158, 33);
            this.btnLogoutHomeForm.TabIndex = 8;
            this.btnLogoutHomeForm.Text = "Logout";
            this.btnLogoutHomeForm.UseVisualStyleBackColor = false;
            this.btnLogoutHomeForm.Click += new System.EventHandler(this.btnLogoutHomeForm_Click);
            // 
            // btnSettingsMenuHomeForm
            // 
            this.btnSettingsMenuHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnSettingsMenuHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_setting_30;
            this.btnSettingsMenuHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSettingsMenuHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSettingsMenuHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSettingsMenuHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettingsMenuHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnSettingsMenuHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnSettingsMenuHomeForm.Location = new System.Drawing.Point(23, 505);
            this.btnSettingsMenuHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnSettingsMenuHomeForm.Name = "btnSettingsMenuHomeForm";
            this.btnSettingsMenuHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnSettingsMenuHomeForm.Size = new System.Drawing.Size(158, 32);
            this.btnSettingsMenuHomeForm.TabIndex = 7;
            this.btnSettingsMenuHomeForm.Text = "Settings";
            this.btnSettingsMenuHomeForm.UseVisualStyleBackColor = false;
            this.btnSettingsMenuHomeForm.Click += new System.EventHandler(this.btnSettingsMenuHomeForm_Click);
            // 
            // btnPolicyHomeForm
            // 
            this.btnPolicyHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnPolicyHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_policy_30;
            this.btnPolicyHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnPolicyHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPolicyHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPolicyHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPolicyHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnPolicyHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnPolicyHomeForm.Location = new System.Drawing.Point(23, 451);
            this.btnPolicyHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnPolicyHomeForm.Name = "btnPolicyHomeForm";
            this.btnPolicyHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnPolicyHomeForm.Size = new System.Drawing.Size(158, 34);
            this.btnPolicyHomeForm.TabIndex = 6;
            this.btnPolicyHomeForm.Text = "Policy";
            this.btnPolicyHomeForm.UseVisualStyleBackColor = false;
            this.btnPolicyHomeForm.Click += new System.EventHandler(this.btnPolicyHomeForm_Click);
            // 
            // btnChargesScheduleHomeForm
            // 
            this.btnChargesScheduleHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnChargesScheduleHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_pay_wall_50;
            this.btnChargesScheduleHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnChargesScheduleHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChargesScheduleHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnChargesScheduleHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChargesScheduleHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnChargesScheduleHomeForm.Location = new System.Drawing.Point(23, 381);
            this.btnChargesScheduleHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnChargesScheduleHomeForm.Name = "btnChargesScheduleHomeForm";
            this.btnChargesScheduleHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnChargesScheduleHomeForm.Size = new System.Drawing.Size(158, 53);
            this.btnChargesScheduleHomeForm.TabIndex = 5;
            this.btnChargesScheduleHomeForm.Text = "Charges Schedule";
            this.btnChargesScheduleHomeForm.UseVisualStyleBackColor = false;
            this.btnChargesScheduleHomeForm.Click += new System.EventHandler(this.btnChargesScheduleHomeForm_Click);
            // 
            // btnManageCardMenuHomeForm
            // 
            this.btnManageCardMenuHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnManageCardMenuHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_card_30__1_;
            this.btnManageCardMenuHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnManageCardMenuHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnManageCardMenuHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnManageCardMenuHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManageCardMenuHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnManageCardMenuHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnManageCardMenuHomeForm.Location = new System.Drawing.Point(23, 327);
            this.btnManageCardMenuHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnManageCardMenuHomeForm.Name = "btnManageCardMenuHomeForm";
            this.btnManageCardMenuHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnManageCardMenuHomeForm.Size = new System.Drawing.Size(158, 30);
            this.btnManageCardMenuHomeForm.TabIndex = 4;
            this.btnManageCardMenuHomeForm.Text = "Manage Card";
            this.btnManageCardMenuHomeForm.UseVisualStyleBackColor = false;
            this.btnManageCardMenuHomeForm.Click += new System.EventHandler(this.btnManageCardMenuHomeForm_Click);
            // 
            // btnTransactionHistoryHomeForm
            // 
            this.btnTransactionHistoryHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnTransactionHistoryHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_transaction_501;
            this.btnTransactionHistoryHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnTransactionHistoryHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTransactionHistoryHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTransactionHistoryHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTransactionHistoryHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnTransactionHistoryHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnTransactionHistoryHomeForm.Location = new System.Drawing.Point(23, 254);
            this.btnTransactionHistoryHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnTransactionHistoryHomeForm.Name = "btnTransactionHistoryHomeForm";
            this.btnTransactionHistoryHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnTransactionHistoryHomeForm.Size = new System.Drawing.Size(158, 52);
            this.btnTransactionHistoryHomeForm.TabIndex = 3;
            this.btnTransactionHistoryHomeForm.Text = "Transaction History";
            this.btnTransactionHistoryHomeForm.UseVisualStyleBackColor = false;
            this.btnTransactionHistoryHomeForm.Click += new System.EventHandler(this.btnTransactionHistoryHomeForm_Click);
            // 
            // btnHomeForm
            // 
            this.btnHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_home_30;
            this.btnHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnHomeForm.Location = new System.Drawing.Point(23, 203);
            this.btnHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnHomeForm.Name = "btnHomeForm";
            this.btnHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnHomeForm.Size = new System.Drawing.Size(158, 31);
            this.btnHomeForm.TabIndex = 2;
            this.btnHomeForm.Text = "Home";
            this.btnHomeForm.UseVisualStyleBackColor = false;
            this.btnHomeForm.Click += new System.EventHandler(this.btnHomeForm_Click);
            // 
            // btnAccountDetailsHomeForm
            // 
            this.btnAccountDetailsHomeForm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnAccountDetailsHomeForm.BackgroundImage = global::Fintech_Vaults.Properties.Resources.icons8_account_30;
            this.btnAccountDetailsHomeForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnAccountDetailsHomeForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAccountDetailsHomeForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAccountDetailsHomeForm.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAccountDetailsHomeForm.ForeColor = System.Drawing.Color.Black;
            this.btnAccountDetailsHomeForm.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnAccountDetailsHomeForm.Location = new System.Drawing.Point(23, 154);
            this.btnAccountDetailsHomeForm.Margin = new System.Windows.Forms.Padding(2);
            this.btnAccountDetailsHomeForm.Name = "btnAccountDetailsHomeForm";
            this.btnAccountDetailsHomeForm.Padding = new System.Windows.Forms.Padding(30, 2, 0, 0);
            this.btnAccountDetailsHomeForm.Size = new System.Drawing.Size(158, 31);
            this.btnAccountDetailsHomeForm.TabIndex = 1;
            this.btnAccountDetailsHomeForm.Text = "Account Details";
            this.btnAccountDetailsHomeForm.UseVisualStyleBackColor = false;
            this.btnAccountDetailsHomeForm.Click += new System.EventHandler(this.btnAccountDetailsHomeForm_Click);
            // 
            // picboxBankLogo
            // 
            this.picboxBankLogo.Image = global::Fintech_Vaults.Properties.Resources.attachment_62465982_removebg_preview;
            this.picboxBankLogo.Location = new System.Drawing.Point(0, 21);
            this.picboxBankLogo.Margin = new System.Windows.Forms.Padding(2);
            this.picboxBankLogo.Name = "picboxBankLogo";
            this.picboxBankLogo.Size = new System.Drawing.Size(221, 119);
            this.picboxBankLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picboxBankLogo.TabIndex = 0;
            this.picboxBankLogo.TabStop = false;
            // 
            // txtOldPassCPS
            // 
            this.txtOldPassCPS.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOldPassCPS.Location = new System.Drawing.Point(423, 195);
            this.txtOldPassCPS.Margin = new System.Windows.Forms.Padding(2);
            this.txtOldPassCPS.Name = "txtOldPassCPS";
            this.txtOldPassCPS.Size = new System.Drawing.Size(243, 38);
            this.txtOldPassCPS.TabIndex = 6;
            // 
            // lblOldPass
            // 
            this.lblOldPass.AutoSize = true;
            this.lblOldPass.BackColor = System.Drawing.Color.Transparent;
            this.lblOldPass.Font = new System.Drawing.Font("Microsoft PhagsPa", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOldPass.Location = new System.Drawing.Point(216, 195);
            this.lblOldPass.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOldPass.Name = "lblOldPass";
            this.lblOldPass.Size = new System.Drawing.Size(197, 36);
            this.lblOldPass.TabIndex = 5;
            this.lblOldPass.Text = "Old Password:";
            // 
            // lblMoneyTransferBAD
            // 
            this.lblMoneyTransferBAD.AutoSize = true;
            this.lblMoneyTransferBAD.Font = new System.Drawing.Font("Bookman Old Style", 32.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMoneyTransferBAD.Location = new System.Drawing.Point(472, 100);
            this.lblMoneyTransferBAD.Name = "lblMoneyTransferBAD";
            this.lblMoneyTransferBAD.Size = new System.Drawing.Size(206, 50);
            this.lblMoneyTransferBAD.TabIndex = 53;
            this.lblMoneyTransferBAD.Text = "Settings";
            // 
            // txtNewPassCPS
            // 
            this.txtNewPassCPS.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNewPassCPS.Location = new System.Drawing.Point(423, 276);
            this.txtNewPassCPS.Margin = new System.Windows.Forms.Padding(2);
            this.txtNewPassCPS.Name = "txtNewPassCPS";
            this.txtNewPassCPS.Size = new System.Drawing.Size(243, 38);
            this.txtNewPassCPS.TabIndex = 55;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft PhagsPa", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(216, 276);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(210, 36);
            this.label1.TabIndex = 54;
            this.label1.Text = "New Password:";
            // 
            // txtConfirmNewPassCPS
            // 
            this.txtConfirmNewPassCPS.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConfirmNewPassCPS.Location = new System.Drawing.Point(541, 361);
            this.txtConfirmNewPassCPS.Margin = new System.Windows.Forms.Padding(2);
            this.txtConfirmNewPassCPS.Name = "txtConfirmNewPassCPS";
            this.txtConfirmNewPassCPS.Size = new System.Drawing.Size(243, 38);
            this.txtConfirmNewPassCPS.TabIndex = 57;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft PhagsPa", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(216, 361);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(321, 36);
            this.label2.TabIndex = 56;
            this.label2.Text = "Confirm New Password:";
            // 
            // btnConfirmPassSetting
            // 
            this.btnConfirmPassSetting.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnConfirmPassSetting.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnConfirmPassSetting.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConfirmPassSetting.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnConfirmPassSetting.Font = new System.Drawing.Font("Microsoft PhagsPa", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirmPassSetting.ForeColor = System.Drawing.Color.Black;
            this.btnConfirmPassSetting.Location = new System.Drawing.Point(437, 468);
            this.btnConfirmPassSetting.Margin = new System.Windows.Forms.Padding(2);
            this.btnConfirmPassSetting.Name = "btnConfirmPassSetting";
            this.btnConfirmPassSetting.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnConfirmPassSetting.Size = new System.Drawing.Size(241, 55);
            this.btnConfirmPassSetting.TabIndex = 58;
            this.btnConfirmPassSetting.Text = "Change Password";
            this.btnConfirmPassSetting.UseVisualStyleBackColor = false;
            this.btnConfirmPassSetting.Click += new System.EventHandler(this.btnConfirmPaymentBAD_Click);
            // 
            // btnChangePassCPS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(1022, 586);
            this.Controls.Add(this.btnConfirmPassSetting);
            this.Controls.Add(this.txtConfirmNewPassCPS);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtNewPassCPS);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblMoneyTransferBAD);
            this.Controls.Add(this.txtOldPassCPS);
            this.Controls.Add(this.lblOldPass);
            this.Controls.Add(this.menuHome);
            this.Name = "btnChangePassCPS";
            this.Text = "ChangePassSetting";
            this.Load += new System.EventHandler(this.ChangePassSetting_Load);
            this.menuHome.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picboxBankLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel menuHome;
        private System.Windows.Forms.Button btnLogoutHomeForm;
        private System.Windows.Forms.Button btnSettingsMenuHomeForm;
        private System.Windows.Forms.Button btnPolicyHomeForm;
        private System.Windows.Forms.Button btnChargesScheduleHomeForm;
        private System.Windows.Forms.Button btnManageCardMenuHomeForm;
        private System.Windows.Forms.Button btnTransactionHistoryHomeForm;
        private System.Windows.Forms.Button btnHomeForm;
        private System.Windows.Forms.Button btnAccountDetailsHomeForm;
        private System.Windows.Forms.PictureBox picboxBankLogo;
        private System.Windows.Forms.TextBox txtOldPassCPS;
        private System.Windows.Forms.Label lblOldPass;
        private System.Windows.Forms.Label lblMoneyTransferBAD;
        private System.Windows.Forms.TextBox txtNewPassCPS;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtConfirmNewPassCPS;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnConfirmPassSetting;
    }
}