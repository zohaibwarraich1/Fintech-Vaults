﻿
namespace Fintech_Vaults.PresentationLayer
{
    partial class Signup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSignUp = new System.Windows.Forms.Button();
            this.txtConfirmPasswordSignUp = new System.Windows.Forms.TextBox();
            this.lblConfirmPasswordSignUp = new System.Windows.Forms.Label();
            this.txtPasswordSignUp = new System.Windows.Forms.TextBox();
            this.lblPasswordSignUp = new System.Windows.Forms.Label();
            this.txtEmailSignUp = new System.Windows.Forms.TextBox();
            this.lblEmailSignUp = new System.Windows.Forms.Label();
            this.txtLastNameSignUp = new System.Windows.Forms.TextBox();
            this.lblLastNameSignUp = new System.Windows.Forms.Label();
            this.txtMobileSignUp = new System.Windows.Forms.TextBox();
            this.lblMobileSignUp = new System.Windows.Forms.Label();
            this.txtFirstNameSignUp = new System.Windows.Forms.TextBox();
            this.lblFirstNameSignUp = new System.Windows.Forms.Label();
            this.lblCreateAccountSignUp = new System.Windows.Forms.Label();
            this.btnShowPassowrdSignUp = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.rdbtnCurrentAccountSignUp = new System.Windows.Forms.RadioButton();
            this.rdbtnSavingAccountSignUp = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // btnSignUp
            // 
            this.btnSignUp.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnSignUp.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnSignUp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSignUp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSignUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSignUp.ForeColor = System.Drawing.Color.White;
            this.btnSignUp.Location = new System.Drawing.Point(452, 539);
            this.btnSignUp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSignUp.Name = "btnSignUp";
            this.btnSignUp.Size = new System.Drawing.Size(148, 36);
            this.btnSignUp.TabIndex = 36;
            this.btnSignUp.Text = "SignUp";
            this.btnSignUp.UseVisualStyleBackColor = false;
            this.btnSignUp.Click += new System.EventHandler(this.btnSignUp_Click);
            // 
            // txtConfirmPasswordSignUp
            // 
            this.txtConfirmPasswordSignUp.BackColor = System.Drawing.Color.Silver;
            this.txtConfirmPasswordSignUp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtConfirmPasswordSignUp.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConfirmPasswordSignUp.ForeColor = System.Drawing.Color.Black;
            this.txtConfirmPasswordSignUp.Location = new System.Drawing.Point(76, 546);
            this.txtConfirmPasswordSignUp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtConfirmPasswordSignUp.Name = "txtConfirmPasswordSignUp";
            this.txtConfirmPasswordSignUp.Size = new System.Drawing.Size(296, 38);
            this.txtConfirmPasswordSignUp.TabIndex = 34;
            this.txtConfirmPasswordSignUp.Tag = "";
            this.txtConfirmPasswordSignUp.UseSystemPasswordChar = true;
            // 
            // lblConfirmPasswordSignUp
            // 
            this.lblConfirmPasswordSignUp.BackColor = System.Drawing.Color.Transparent;
            this.lblConfirmPasswordSignUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConfirmPasswordSignUp.ForeColor = System.Drawing.Color.Black;
            this.lblConfirmPasswordSignUp.Location = new System.Drawing.Point(72, 518);
            this.lblConfirmPasswordSignUp.Name = "lblConfirmPasswordSignUp";
            this.lblConfirmPasswordSignUp.Size = new System.Drawing.Size(212, 24);
            this.lblConfirmPasswordSignUp.TabIndex = 33;
            this.lblConfirmPasswordSignUp.Text = "Confirm Password:";
            // 
            // txtPasswordSignUp
            // 
            this.txtPasswordSignUp.BackColor = System.Drawing.Color.Silver;
            this.txtPasswordSignUp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPasswordSignUp.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPasswordSignUp.ForeColor = System.Drawing.Color.Black;
            this.txtPasswordSignUp.Location = new System.Drawing.Point(76, 446);
            this.txtPasswordSignUp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtPasswordSignUp.Name = "txtPasswordSignUp";
            this.txtPasswordSignUp.Size = new System.Drawing.Size(296, 38);
            this.txtPasswordSignUp.TabIndex = 32;
            this.txtPasswordSignUp.Tag = "";
            this.txtPasswordSignUp.UseSystemPasswordChar = true;
            // 
            // lblPasswordSignUp
            // 
            this.lblPasswordSignUp.BackColor = System.Drawing.Color.Transparent;
            this.lblPasswordSignUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPasswordSignUp.ForeColor = System.Drawing.Color.Black;
            this.lblPasswordSignUp.Location = new System.Drawing.Point(72, 418);
            this.lblPasswordSignUp.Name = "lblPasswordSignUp";
            this.lblPasswordSignUp.Size = new System.Drawing.Size(108, 24);
            this.lblPasswordSignUp.TabIndex = 31;
            this.lblPasswordSignUp.Text = "Password:";
            // 
            // txtEmailSignUp
            // 
            this.txtEmailSignUp.BackColor = System.Drawing.Color.Silver;
            this.txtEmailSignUp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEmailSignUp.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmailSignUp.ForeColor = System.Drawing.Color.Black;
            this.txtEmailSignUp.Location = new System.Drawing.Point(76, 348);
            this.txtEmailSignUp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtEmailSignUp.Name = "txtEmailSignUp";
            this.txtEmailSignUp.Size = new System.Drawing.Size(296, 38);
            this.txtEmailSignUp.TabIndex = 30;
            this.txtEmailSignUp.Tag = "";
            // 
            // lblEmailSignUp
            // 
            this.lblEmailSignUp.BackColor = System.Drawing.Color.Transparent;
            this.lblEmailSignUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailSignUp.ForeColor = System.Drawing.Color.Black;
            this.lblEmailSignUp.Location = new System.Drawing.Point(72, 320);
            this.lblEmailSignUp.Name = "lblEmailSignUp";
            this.lblEmailSignUp.Size = new System.Drawing.Size(108, 24);
            this.lblEmailSignUp.TabIndex = 29;
            this.lblEmailSignUp.Text = "Email:";
            // 
            // txtLastNameSignUp
            // 
            this.txtLastNameSignUp.BackColor = System.Drawing.Color.Silver;
            this.txtLastNameSignUp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLastNameSignUp.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLastNameSignUp.ForeColor = System.Drawing.Color.Black;
            this.txtLastNameSignUp.Location = new System.Drawing.Point(581, 134);
            this.txtLastNameSignUp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtLastNameSignUp.Name = "txtLastNameSignUp";
            this.txtLastNameSignUp.Size = new System.Drawing.Size(296, 38);
            this.txtLastNameSignUp.TabIndex = 28;
            this.txtLastNameSignUp.Tag = "";
            // 
            // lblLastNameSignUp
            // 
            this.lblLastNameSignUp.BackColor = System.Drawing.Color.Transparent;
            this.lblLastNameSignUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLastNameSignUp.ForeColor = System.Drawing.Color.Black;
            this.lblLastNameSignUp.Location = new System.Drawing.Point(577, 106);
            this.lblLastNameSignUp.Name = "lblLastNameSignUp";
            this.lblLastNameSignUp.Size = new System.Drawing.Size(123, 24);
            this.lblLastNameSignUp.TabIndex = 27;
            this.lblLastNameSignUp.Text = "Last Name:";
            // 
            // txtMobileSignUp
            // 
            this.txtMobileSignUp.BackColor = System.Drawing.Color.Silver;
            this.txtMobileSignUp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMobileSignUp.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMobileSignUp.ForeColor = System.Drawing.Color.Black;
            this.txtMobileSignUp.Location = new System.Drawing.Point(581, 223);
            this.txtMobileSignUp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtMobileSignUp.Name = "txtMobileSignUp";
            this.txtMobileSignUp.Size = new System.Drawing.Size(296, 38);
            this.txtMobileSignUp.TabIndex = 26;
            this.txtMobileSignUp.Tag = "";
            // 
            // lblMobileSignUp
            // 
            this.lblMobileSignUp.BackColor = System.Drawing.Color.Transparent;
            this.lblMobileSignUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMobileSignUp.ForeColor = System.Drawing.Color.Black;
            this.lblMobileSignUp.Location = new System.Drawing.Point(577, 196);
            this.lblMobileSignUp.Name = "lblMobileSignUp";
            this.lblMobileSignUp.Size = new System.Drawing.Size(172, 24);
            this.lblMobileSignUp.TabIndex = 25;
            this.lblMobileSignUp.Text = "Mobile Number:";
            // 
            // txtFirstNameSignUp
            // 
            this.txtFirstNameSignUp.BackColor = System.Drawing.Color.Silver;
            this.txtFirstNameSignUp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtFirstNameSignUp.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFirstNameSignUp.ForeColor = System.Drawing.Color.Black;
            this.txtFirstNameSignUp.Location = new System.Drawing.Point(76, 134);
            this.txtFirstNameSignUp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtFirstNameSignUp.Name = "txtFirstNameSignUp";
            this.txtFirstNameSignUp.Size = new System.Drawing.Size(296, 38);
            this.txtFirstNameSignUp.TabIndex = 23;
            this.txtFirstNameSignUp.Tag = "";
            // 
            // lblFirstNameSignUp
            // 
            this.lblFirstNameSignUp.BackColor = System.Drawing.Color.Transparent;
            this.lblFirstNameSignUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstNameSignUp.ForeColor = System.Drawing.Color.Black;
            this.lblFirstNameSignUp.Location = new System.Drawing.Point(72, 106);
            this.lblFirstNameSignUp.Name = "lblFirstNameSignUp";
            this.lblFirstNameSignUp.Size = new System.Drawing.Size(132, 24);
            this.lblFirstNameSignUp.TabIndex = 22;
            this.lblFirstNameSignUp.Text = "First Name:";
            // 
            // lblCreateAccountSignUp
            // 
            this.lblCreateAccountSignUp.AutoSize = true;
            this.lblCreateAccountSignUp.BackColor = System.Drawing.Color.Transparent;
            this.lblCreateAccountSignUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCreateAccountSignUp.ForeColor = System.Drawing.Color.Black;
            this.lblCreateAccountSignUp.Location = new System.Drawing.Point(387, 31);
            this.lblCreateAccountSignUp.Name = "lblCreateAccountSignUp";
            this.lblCreateAccountSignUp.Size = new System.Drawing.Size(281, 33);
            this.lblCreateAccountSignUp.TabIndex = 21;
            this.lblCreateAccountSignUp.Text = "Create an Account!";
            // 
            // btnShowPassowrdSignUp
            // 
            this.btnShowPassowrdSignUp.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnShowPassowrdSignUp.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnShowPassowrdSignUp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnShowPassowrdSignUp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnShowPassowrdSignUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowPassowrdSignUp.ForeColor = System.Drawing.Color.White;
            this.btnShowPassowrdSignUp.Location = new System.Drawing.Point(382, 446);
            this.btnShowPassowrdSignUp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnShowPassowrdSignUp.Name = "btnShowPassowrdSignUp";
            this.btnShowPassowrdSignUp.Size = new System.Drawing.Size(71, 36);
            this.btnShowPassowrdSignUp.TabIndex = 37;
            this.btnShowPassowrdSignUp.Text = "Show";
            this.btnShowPassowrdSignUp.UseVisualStyleBackColor = false;
            this.btnShowPassowrdSignUp.Click += new System.EventHandler(this.btnShowPassowrdSignUp_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(72, 196);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(172, 24);
            this.label1.TabIndex = 38;
            this.label1.Text = "Account Type:";
            // 
            // rdbtnCurrentAccountSignUp
            // 
            this.rdbtnCurrentAccountSignUp.BackColor = System.Drawing.Color.Transparent;
            this.rdbtnCurrentAccountSignUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnCurrentAccountSignUp.ForeColor = System.Drawing.Color.Black;
            this.rdbtnCurrentAccountSignUp.Location = new System.Drawing.Point(76, 227);
            this.rdbtnCurrentAccountSignUp.Margin = new System.Windows.Forms.Padding(2);
            this.rdbtnCurrentAccountSignUp.Name = "rdbtnCurrentAccountSignUp";
            this.rdbtnCurrentAccountSignUp.Size = new System.Drawing.Size(180, 33);
            this.rdbtnCurrentAccountSignUp.TabIndex = 39;
            this.rdbtnCurrentAccountSignUp.TabStop = true;
            this.rdbtnCurrentAccountSignUp.Text = "Current Account";
            this.rdbtnCurrentAccountSignUp.UseVisualStyleBackColor = false;
            this.rdbtnCurrentAccountSignUp.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // rdbtnSavingAccountSignUp
            // 
            this.rdbtnSavingAccountSignUp.BackColor = System.Drawing.Color.Transparent;
            this.rdbtnSavingAccountSignUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtnSavingAccountSignUp.ForeColor = System.Drawing.Color.Black;
            this.rdbtnSavingAccountSignUp.Location = new System.Drawing.Point(76, 264);
            this.rdbtnSavingAccountSignUp.Margin = new System.Windows.Forms.Padding(2);
            this.rdbtnSavingAccountSignUp.Name = "rdbtnSavingAccountSignUp";
            this.rdbtnSavingAccountSignUp.Size = new System.Drawing.Size(192, 33);
            this.rdbtnSavingAccountSignUp.TabIndex = 40;
            this.rdbtnSavingAccountSignUp.TabStop = true;
            this.rdbtnSavingAccountSignUp.Text = "Saving Account";
            this.rdbtnSavingAccountSignUp.UseVisualStyleBackColor = false;
            // 
            // Signup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Fintech_Vaults.Properties.Resources.vaults_with_money_bag;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1022, 673);
            this.Controls.Add(this.rdbtnSavingAccountSignUp);
            this.Controls.Add(this.rdbtnCurrentAccountSignUp);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnShowPassowrdSignUp);
            this.Controls.Add(this.btnSignUp);
            this.Controls.Add(this.txtConfirmPasswordSignUp);
            this.Controls.Add(this.lblConfirmPasswordSignUp);
            this.Controls.Add(this.txtPasswordSignUp);
            this.Controls.Add(this.lblPasswordSignUp);
            this.Controls.Add(this.txtEmailSignUp);
            this.Controls.Add(this.lblEmailSignUp);
            this.Controls.Add(this.txtLastNameSignUp);
            this.Controls.Add(this.lblLastNameSignUp);
            this.Controls.Add(this.txtMobileSignUp);
            this.Controls.Add(this.lblMobileSignUp);
            this.Controls.Add(this.txtFirstNameSignUp);
            this.Controls.Add(this.lblFirstNameSignUp);
            this.Controls.Add(this.lblCreateAccountSignUp);
            this.Name = "Signup";
            this.Text = "Signup";
            this.Load += new System.EventHandler(this.Signup_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSignUp;
        private System.Windows.Forms.TextBox txtConfirmPasswordSignUp;
        private System.Windows.Forms.Label lblConfirmPasswordSignUp;
        private System.Windows.Forms.TextBox txtPasswordSignUp;
        private System.Windows.Forms.Label lblPasswordSignUp;
        private System.Windows.Forms.TextBox txtEmailSignUp;
        private System.Windows.Forms.Label lblEmailSignUp;
        private System.Windows.Forms.TextBox txtLastNameSignUp;
        private System.Windows.Forms.Label lblLastNameSignUp;
        private System.Windows.Forms.TextBox txtMobileSignUp;
        private System.Windows.Forms.Label lblMobileSignUp;
        private System.Windows.Forms.TextBox txtFirstNameSignUp;
        private System.Windows.Forms.Label lblFirstNameSignUp;
        private System.Windows.Forms.Label lblCreateAccountSignUp;
        private System.Windows.Forms.Button btnShowPassowrdSignUp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rdbtnCurrentAccountSignUp;
        private System.Windows.Forms.RadioButton rdbtnSavingAccountSignUp;
    }
}