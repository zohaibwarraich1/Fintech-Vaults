﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Fintech_Vaults.BusinessLayer;
using Fintech_Vaults.DataLayer;
namespace Fintech_Vaults.PresentationLayer
{
    public partial class CreditCardForm : Form
    {
        public CreditCardForm()
        {
            InitializeComponent();
        }

        private void CreditCardForm_Load(object sender, EventArgs e)
        {
            CreditCards c = new CreditCards();
            DBConnection.CreditCardDetails(c);
            txtCardNumber.Text = c.FormatCardNumber(c.CardID.ToString());
            txtCardName.Text = c.CardName.ToUpper();
            txtExpiry.Text = "Expiry: " + c.ExpiryDate;
            txtCVV.Text = "CVV:  " + c.CVV.ToString();
            if (DBConnection.CheckActivationStatus())
            {
                btnActivate.Visible = true;
                btnChangePin.Visible = false;
            }
            else
            {
                btnActivate.Visible = false;
                btnChangePin.Visible = true;
            }
        }

        private void btnManageCardMenuHomeForm_Click(object sender, EventArgs e)
        {

        }

        private void btnAccountDetailsHomeForm_Click(object sender, EventArgs e)
        {
            AccountForm a = new AccountForm();
            this.Hide();
            a.Show();
        }

        private void btnHomeForm_Click(object sender, EventArgs e)
        {
            HomeForm h = new HomeForm();
            this.Hide();
            h.Show();
        }

        private void btnTransactionHistoryHomeForm_Click(object sender, EventArgs e)
        {
            TransactionHistory t = new TransactionHistory();
            t.Show();
            this.Hide();
        }

        private void btnChargesScheduleHomeForm_Click(object sender, EventArgs e)
        {
            Charges c = new Charges();
            this.Hide();
            c.Show();
        }

        private void btnPolicyHomeForm_Click(object sender, EventArgs e)
        {
            Policy p = new Policy();
            p.Show();
            this.Hide();
        }

        private void btnSettingsMenuHomeForm_Click(object sender, EventArgs e)
        {
            Settings s = new Settings();
            this.Hide();
            s.Show();
        }

        private void btnLogoutHomeForm_Click(object sender, EventArgs e)
        {
            LoginForm l = new LoginForm();
            l.Show();
            this.Hide();
        }

        private void btnActivate_Click(object sender, EventArgs e)
        {
            DBConnection.UpdateActivationStatus();
            CardActivation ca = new CardActivation();
            ca.Show();
            this.Hide();
        }

        private void btnChangePin_Click(object sender, EventArgs e)
        {
            CardActivation ca = new CardActivation();
            ca.Show();
            this.Hide();
        }
    }
}
