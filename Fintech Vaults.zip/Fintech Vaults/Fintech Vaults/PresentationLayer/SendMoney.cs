﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Fintech_Vaults.BusinessLayer;
using Fintech_Vaults.DataLayer;

namespace Fintech_Vaults.PresentationLayer
{
    public partial class SendMoney : Form
    {
        private Transaction beneficiaryAccount = new Transaction();
        public SendMoney()
        {
            InitializeComponent();
        }
        private void txtPasswordSendMoney_TextChanged(object sender, EventArgs e)
        {

        }
        private void btnNextSendMoney_Click(object sender, EventArgs e)
        {
            beneficiaryAccount.Amount = int.Parse(txtAmountSendMoney.Text);
            beneficiaryAccount.AccountID = int.Parse(txtBeneficiaryAccountNoSendMoney.Text);
            string pass = txtPasswordSendMoney.Text;
            if (DBConnection.MoneyTransferPassVerify(pass))
            {
                if (DBConnection.MoneyTransferBeneficiaryAccIDVerify(beneficiaryAccount.AccountID))
                {
                    BeneficiaryAccountDetail bad1 = new BeneficiaryAccountDetail(beneficiaryAccount.Amount, beneficiaryAccount.AccountID);
                    this.Hide();
                    bad1.Show();
                }
                else
                {
                    MessageBox.Show("You have entered wrong Account ID!", "Wrong Account ID", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtBeneficiaryAccountNoSendMoney.Clear();
                }
            }
            else
            {
                MessageBox.Show("You have enetered wrong Password!", "Wrong Password", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPasswordSendMoney.Clear();
            }
        }
        private void btnAccountDetailsHomeForm_Click(object sender, EventArgs e)
        {
            AccountForm af1 = new AccountForm();
            af1.Show();
            this.Hide();
        }

        private void btnHomeForm_Click(object sender, EventArgs e)
        {
            HomeForm hf1 = new HomeForm();
            hf1.Show();
            this.Hide();
        }

        private void btnLogoutHomeForm_Click(object sender, EventArgs e)
        {
            LoginForm lf1 = new LoginForm();
            lf1.Show();
            this.Hide();
        }

        private void btnShowPassAccountForm_Click(object sender, EventArgs e)
        {
            if (btnShowPassAccountForm.Text == "Hide")
            {
                txtPasswordSendMoney.UseSystemPasswordChar = true;
                btnShowPassAccountForm.Text = "Show";
            }
            else
            {
                txtPasswordSendMoney.UseSystemPasswordChar = false;
                btnShowPassAccountForm.Text = "Hide";
            }
        }

        private void btnSettingsMenuHomeForm_Click(object sender, EventArgs e)
        {
            Settings s1 = new Settings();
            this.Hide();
            s1.Show();
        }

        private void btnPolicyHomeForm_Click(object sender, EventArgs e)
        {
            Policy p = new Policy();
            p.Show();
            this.Hide();
        }

        private void btnChargesScheduleHomeForm_Click(object sender, EventArgs e)
        {
            Charges ch = new Charges();
            ch.Show();
            this.Hide();
        }

        private void btnTransactionHistoryHomeForm_Click(object sender, EventArgs e)
        {
            TransactionHistory t = new TransactionHistory();
            t.Show();
            this.Hide();
        }

        private void btnManageCardMenuHomeForm_Click(object sender, EventArgs e)
        {
            CreditCardForm c = new CreditCardForm();
            c.Show();
            this.Hide();
        }

        private void SendMoney_Load(object sender, EventArgs e)
        {

        }
    }
}
