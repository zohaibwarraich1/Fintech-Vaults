﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Fintech_Vaults.BusinessLayer;
using Fintech_Vaults.DataLayer;
namespace Fintech_Vaults.PresentationLayer
{
    public partial class AccountForm : Form
    {
        public AccountForm()
        {
            InitializeComponent();
        }

        private void Name_TextChanged(object sender, EventArgs e)
        {

        }

        private void AccountForm_Load(object sender, EventArgs e)
        {
            User usr1 = new User();
            DBConnection.AccountOverview(usr1);
            txtMobileNumberAccountForm.Text = usr1.MobileNo.ToString();
            txtPasswordAccountForm.Text = usr1.Password;
            txtAccountNameAccountForm.Text = usr1.FullName;
            txtEmailAccountForm.Text = usr1.Email;
            txtAccountNumberAccountForm.Text = Account.AccountID.ToString();

        }

        private void email_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnAccountDetailsHomeForm_Click(object sender, EventArgs e)
        {

        }

        private void btnHomeForm_Click(object sender, EventArgs e)
        {
            HomeForm hf1 = new HomeForm();
            hf1.Show();
            this.Hide();
        }
        private void btnShowPassAccountForm_Click(object sender, EventArgs e)
        {
            User user = new User();
            if (user.CheckPasswordShowOption(btnShowPassAccountForm.Text))
            {
                txtPasswordAccountForm.UseSystemPasswordChar = true;
                btnShowPassAccountForm.Text = "Show";
            }
            else
            {
                txtPasswordAccountForm.UseSystemPasswordChar = false;
                btnShowPassAccountForm.Text = "Hide";
            }
        }

        private void btnLogoutHomeForm_Click(object sender, EventArgs e)
        {
            LoginForm lf1 = new LoginForm();
            lf1.Show();
            this.Hide();
        }

        private void btnSettingsMenuHomeForm_Click(object sender, EventArgs e)
        {
            Settings s1 = new Settings();
            this.Hide();
            s1.Show();
        }

        private void btnPolicyHomeForm_Click(object sender, EventArgs e)
        {
            Policy p = new Policy();
            p.Show();
            this.Hide();
        }

        private void btnChargesScheduleHomeForm_Click(object sender, EventArgs e)
        {
            Charges ch = new Charges();
            ch.Show();
            this.Hide();
        }

        private void btnTransactionHistoryHomeForm_Click(object sender, EventArgs e)
        {
            TransactionHistory t = new TransactionHistory();
            t.Show();
            this.Hide();
        }

        private void btnManageCardMenuHomeForm_Click(object sender, EventArgs e)
        {
            CreditCardForm c = new CreditCardForm();
            c.Show();
            this.Hide();
        }
    }
}
