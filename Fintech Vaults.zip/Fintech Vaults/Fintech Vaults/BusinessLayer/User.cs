﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Fintech_Vaults.DataLayer;
using Fintech_Vaults.PresentationLayer;
namespace Fintech_Vaults.BusinessLayer
{
    class User
    {
        private Account acc;
        private static int userID;
        private string fullName;
        private string email;
        private string password;
        private long mobileNo;
        private Policy policy;
        public User()
        {
            acc = new Account();
        }
        public User(int userID, string fullName, string email, string pass, long mobileNo, Account acc)
        {
            User.userID = userID;
            this.fullName = fullName;
            this.email = email;
            this.password = pass;
            this.mobileNo = mobileNo;
            acc = new Account();
            this.acc = acc;
        }
        public Account TheAccount
        {
            set
            {
                acc = value;
            }
            get { return acc; }
        }
        public Policy Policy
        {
            set
            {
                policy = new Policy();
                policy = value;
            }
            get { return policy; }
        }
        public static int UserID
        {
            get { return userID; }
            set { userID = value; }
        }
        public string FullName
        {
            get { return fullName; }
            set { fullName = value; }
        }
        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        public string Password
        {
            get { return password; }
            set { password = value; }
        }
        public long MobileNo
        {
            get { return mobileNo; }
            set { mobileNo = value; }
        }
        public bool CheckPasswordShowOption(string text)
        {
            if (text == "Hide")
            {
                return true;
            }
            return false;
        }
    }
}
