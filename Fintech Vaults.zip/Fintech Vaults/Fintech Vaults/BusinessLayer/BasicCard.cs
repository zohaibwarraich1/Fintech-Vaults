﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fintech_Vaults.BusinessLayer
{
    class BasicCard : CreditCards
    {
        private int cardLimit;
        public BasicCard()
        {

        }
        public BasicCard(int cardid, int accid, string exdate, int cvv, string cardName, int cardPin, int cardlimit) : base(cardid, accid, exdate, cvv, cardName, cardPin)
        {
            this.cardLimit = cardlimit;
        }
        public int CardLimit
        {
            set { cardLimit = value; }
            get { return cardLimit; }
        }
    }
}
