﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Fintech_Vaults.DataLayer;
using Fintech_Vaults.PresentationLayer;
namespace Fintech_Vaults.BusinessLayer
{
    class CurrentAccount : Account
    {
        private int overdraftLimit;
        public CurrentAccount(int userID, int balance, string accountType, Setting setting, int overdraftLimit) : base(userID, balance, accountType, setting)
        {
            this.overdraftLimit = overdraftLimit;
        }
        public int OverdraftLimit
        {
            set { overdraftLimit = value; }
            get { return overdraftLimit; }
        }
    }
}
