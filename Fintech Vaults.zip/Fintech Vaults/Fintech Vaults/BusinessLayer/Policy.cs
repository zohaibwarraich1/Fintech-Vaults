﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fintech_Vaults.BusinessLayer
{
    class Policy
    {
        private int policyID;
        private string text;
        public Policy()
        {

        }
        public int PolicyID
        {
            set { policyID = value; }
            get { return policyID; }
        }
        public string PolicyText
        {
            set { text = value; }
            get { return text; }
        }
    }
}
