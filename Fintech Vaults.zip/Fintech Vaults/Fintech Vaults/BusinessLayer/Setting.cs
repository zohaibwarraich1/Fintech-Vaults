﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Fintech_Vaults.DataLayer;
using Fintech_Vaults.PresentationLayer;
namespace Fintech_Vaults.BusinessLayer
{
    class Setting
    {
        private string changePassword;
        private string changeEmail;
        public Setting()
        {

        }
        public Setting(string changePass, string changeEmail)
        {
            this.changeEmail = changeEmail;
            this.changePassword = changePass;
        }
        public string ChangedPassword
        {
            set { changePassword = value; }
            get { return changePassword; }
        }
        public string ChangedEmail
        {
            set { changeEmail = value; }
            get { return changeEmail; }
        }
    }
}
