﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fintech_Vaults.BusinessLayer
{
    class Transaction
    {
        private int accountID;
        private int beneficiaryID;
        private int chargeID;
        private string transactionType;
        private int amount;
        private string time;
        public Transaction()
        {

        }
        public Transaction(int accID, int beneficiaryId, int chargeId, string type, int amount, string time)
        {
            this.accountID = accID;
            this.beneficiaryID = beneficiaryId;
            this.chargeID = chargeId;
            this.transactionType = type;
            this.amount = amount;
            this.time = time;
        }
        public int AccountID
        {
            set { accountID = value; }
            get { return accountID; }
        }
        public int BeneficiaryID
        {
            set { beneficiaryID = value; }
            get { return beneficiaryID; }
        }
        public int ChargeID
        {
            set { chargeID = value; }
            get { return chargeID; }
        }
        public string TransactionType
        {
            set { transactionType = value; }
            get { return transactionType; }
        }
        public int Amount
        {
            set { amount = value; }
            get { return amount; }
        }
        public string Time
        {
            set { time = value; }
            get { return time; }
        }
        public void CalculateChargedAmount(Transaction beneficiary, Charges c1, int previousTempChargeIndex, int tempchargeID)
        {
            beneficiary.Amount = beneficiary.Amount - previousTempChargeIndex;
            c1.ChargeID = tempchargeID;
        }
    }
}
