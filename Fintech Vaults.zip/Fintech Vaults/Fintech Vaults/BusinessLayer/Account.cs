﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fintech_Vaults.BusinessLayer
{
    class Account
    {
        private Setting setting;
        protected static int accountID;
        protected int userID;
        protected int balance;
        protected string accountType;
        private CreditCards card;
        private Transaction transaction;
        private Charges charges;
        public Account()
        {
            setting = new Setting();
            card = new CreditCards();
            transaction = new Transaction();
            charges = new Charges();
        }
        public Account(int userID, int balance, string accountType, Setting setting, CreditCards card, Transaction trans, Charges charges)
        {
            this.userID = userID;
            this.balance = balance;
            this.accountType = accountType;
            setting = new Setting();
            this.setting = setting;
            card = new CreditCards();
            this.card = card;
            transaction = new Transaction();
            this.transaction = trans;
            charges = new Charges();
            this.charges = charges;
        }
        public Setting Setting
        {
            set { setting = value; }
            get { return setting; }
        }
        public Transaction Transaction
        {
            set { transaction = value; }
            get { return transaction; }
        }
        public Charges Charges
        {
            set { charges = value; }
            get { return charges; }
        }
        public CreditCards Card
        {
            set
            {
                card = value;
            }
            get { return card; }
        }
        public static int AccountID
        {
            set { accountID = value; }
            get { return accountID; }
        }
        public int UserID
        {
            set
            {
                userID = value;
            }
            get { return userID; }
        }
        public int Balance
        {
            set
            {
                balance = value;
            }
            get { return balance; }
        }
        public string AccountType
        {
            set { accountType = value; }
            get { return accountType; }
        }
        public bool CheckShowBalanceOption(string text)
        {
            if (text == "Show")
            {
                return true;
            }
            return false;
        }
    }
}
