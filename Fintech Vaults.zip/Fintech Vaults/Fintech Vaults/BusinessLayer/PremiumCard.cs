﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fintech_Vaults.BusinessLayer
{
    class PremiumCard : CreditCards
    {
        private int chargesDiscount;
        public PremiumCard()
        {

        }
        public PremiumCard(int cardid, int accid, string exdate, int cvv, string cardName, int cardPin, int discount) : base(cardid, accid, exdate, cvv, cardName, cardPin)
        {
            this.chargesDiscount = discount;
        }
        public int ChargesDiscount
        {
            set { chargesDiscount = value; }
            get { return chargesDiscount; }
        }
    }
}
