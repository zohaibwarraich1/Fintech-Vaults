﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fintech_Vaults.BusinessLayer
{
    class CreditCards
    {
        private long cardID;
        private int AccountId;
        private string expiryDate;
        private int cvv;
        private string cardName;
        private string activationStatus;
        private int cardPin;
        public CreditCards()
        {

        }
        public CreditCards(int cardid, int accid, string exdate, int cvv, string cardName, int cardPin)
        {
            this.cardID = cardid;
            this.AccountId = accid;
            this.expiryDate = exdate;
            this.cvv = cvv;
            this.cardName = cardName;
            this.cardPin = cardPin;
        }
        public CreditCards(string activiation)
        {
            this.activationStatus = activiation;
        }
        public long CardID
        {
            set { cardID = value; }
            get { return cardID; }
        }
        public int AccountID
        {
            set { AccountId = value; }
            get { return AccountId; }
        }
        public string ExpiryDate
        {
            set { expiryDate = value; }
            get { return expiryDate; }
        }
        public int CVV
        {
            set { cvv = value; }
            get { return cvv; }
        }
        public string CardName
        {
            set { cardName = value; }
            get { return cardName; }
        }
        public int CardPin
        {
            set { cardPin = value; }
            get { return cardPin; }
        }
        public string FormatCardNumber(string cardNumber)
        {
            string firstFour = "";
            string secFour = "";
            string thirdFour = "";
            string lastFour = "";
            for (int i = 0; i < cardNumber.Length; i++)
            {
                if (i <= 3)
                {
                    firstFour += cardNumber[i];
                }
                else if (i >= 4 && i <= 7)
                {
                    secFour += cardNumber[i];
                }
                else if (i >= 8 && i <= 11)
                {
                    thirdFour += cardNumber[i];
                }
                else if (i >= 12 && i <= 15)
                {
                    lastFour += cardNumber[i];
                }
            }
            string finalNo = "      " + firstFour + "   " + secFour + "   " + thirdFour + "   " + lastFour;
            return finalNo;
        }
    }
}

