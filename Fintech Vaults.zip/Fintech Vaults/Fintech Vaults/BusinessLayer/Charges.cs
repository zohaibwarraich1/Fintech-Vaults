﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Fintech_Vaults.DataLayer;
using Fintech_Vaults.PresentationLayer;
namespace Fintech_Vaults.BusinessLayer
{
    class Charges
    {
        private int chargeID;
        private double transactionAmount;
        private double chargeAmount;
        public Charges()
        {

        }
        public int ChargeID
        {
            set { chargeID = value; }
            get { return chargeID; }
        }
        public double TransactionAmount
        {
            set { transactionAmount = value; }
            get { return transactionAmount; }
        }
        public double ChargeAmount
        {
            set { chargeAmount = value; }
            get { return chargeAmount; }
        }
    }
}
