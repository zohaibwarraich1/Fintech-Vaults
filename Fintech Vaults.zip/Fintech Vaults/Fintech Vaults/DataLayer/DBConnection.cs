﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Fintech_Vaults.BusinessLayer;
using Fintech_Vaults.PresentationLayer;
using System.Data;

namespace Fintech_Vaults.DataLayer
{
    class DBConnection
    {
        private static string connection = "Data Source=DESKTOP-7GRG9TJ\\SQLEXPRESS;Initial Catalog=FintechVaults;Integrated Security=True";
        public static void LoginID(User usr, string loginEmail, string loginPass)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string Query = "select UserID, Email, [Password], MobileNo, FullName from[User] where Email = '" + loginEmail + "' AND [Password] = '" + loginPass + "';";
            SqlCommand cmd = new SqlCommand(Query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                usr.Email = reader["Email"].ToString();
                usr.Password = reader["Password"].ToString();
                usr.FullName = reader["FullName"].ToString();
                /*User.UserID = int.Parse(reader["UserID"].ToString());*/
                usr.MobileNo = long.Parse(reader["MobileNo"].ToString());
            }
            con.Close();
        }
        public static void SignUpAccount(User usr1)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string Query = "Insert into[User](FullName, Email,[Password],MobileNo) Values('" + usr1.FullName.ToUpper() + "', '" + usr1.Email + "', '" + usr1.Password + "', " + usr1.MobileNo + ")";
            SqlCommand cmd = new SqlCommand(Query, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public static int CheckUserIDForCreatingAccount(User usr1)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string readQuery = "Select UserID from [User] where Email='" + usr1.Email + "' AND [Password]='" + usr1.Password + "';";
            SqlCommand cmd = new SqlCommand(readQuery, con);
            SqlDataReader reader = cmd.ExecuteReader();
            int userID = -1;
            while (reader.Read())
            {
                userID = int.Parse(reader["UserID"].ToString());
            }
            return userID;
        }
        public static void CreateAccountUsingUSerID(int userID, bool currentAccount, bool savingAccount)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string AccountQuery = "";
            if (currentAccount)
            {
                AccountQuery = "Insert into Account(UserID, Balance, AccountType) Values(" + userID + "," + 0 + " , '" + "Current Account" + "'); ";
            }
            else
            {
                AccountQuery = "Insert into Account(UserID, Balance, AccountType) Values(" + userID + "," + 0 + " , '" + "Saving Account" + "'); ";
            }
            SqlCommand cmd = new SqlCommand(AccountQuery, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public static int CheckingAccountIDForCreatingCredtiCard(int userID)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string query = "Select AccountID from Account where UserID = " + userID + ";";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            int accountID = -1;
            while (reader.Read())
            {
                accountID = int.Parse(reader["AccountID"].ToString());
            }
            con.Close();
            return accountID;
        }
        public static void CreateCreditCard(CreditCards c)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string query = "insert into CreditCard(AccountID, ExpiryDate, CardName) Values(" + c.AccountID + ", '" + c.ExpiryDate + "', '" + c.CardName + "');";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public static int ShowBalanceHomePage()
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string query = "select Balance from Account where UserID = " + User.UserID;
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            int userBalance = 0;
            while (reader.Read())
            {
                userBalance = int.Parse(reader["Balance"].ToString());
            }
            con.Close();
            return userBalance;
        }
        public static bool MatchPassword(string pass)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string queryMatchPass = "select [Password] from [User] where UserID = " + User.UserID + ";";
            SqlCommand cmd = new SqlCommand(queryMatchPass, con);
            SqlDataReader reader = cmd.ExecuteReader();
            string passToMatch = "";
            while (reader.Read())
            {
                passToMatch = reader["Password"].ToString();
            }
            con.Close();
            if (passToMatch == pass)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static void DepositAmount(long depositAmount)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string queryCheckbalance = "select Balance from Account where UserID = " + User.UserID + ";";
            SqlCommand cmd = new SqlCommand(queryCheckbalance, con);
            SqlDataReader reader = cmd.ExecuteReader();
            long amount = 0;
            while (reader.Read())
            {
                amount = long.Parse(reader["Balance"].ToString());
            }
            con.Close();
            amount += depositAmount;
            SqlConnection con2 = new SqlConnection(connection);
            con2.Open();
            string queryAddAmount = "update Account set Balance = " + amount + "where UserID = " + User.UserID + ";";
            SqlCommand cmd2 = new SqlCommand(queryAddAmount, con2);
            cmd2.ExecuteNonQuery();
            con2.Close();
        }
        public static void NecessaryStaticDetails(string email, string pass)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string Query = "Select [User].UserID, Account.AccountID From [User] Join Account ON Account.UserID = [User].UserID where [User].Email = '" + email + "' AND [User].[Password] = '" + pass + "';";
            SqlCommand cmd = new SqlCommand(Query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                User.UserID = int.Parse(reader["UserID"].ToString());
                Account.AccountID = int.Parse(reader["AccountID"].ToString());
            }
            con.Close();
        }
        public static void AccountOverview(User usr1)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string Query = "SELECT [User].FullName, [User].Email, [User].[Password], [User].MobileNo, Account.AccountID FROM [User] JOIN Account ON Account.UserID = [User].UserID where Account.AccountID = '" + Account.AccountID + "';";
            SqlCommand cmd = new SqlCommand(Query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                usr1.Email = reader["Email"].ToString();
                usr1.FullName = reader["FullName"].ToString();
                usr1.Password = reader["Password"].ToString();
                usr1.MobileNo = long.Parse(reader["MobileNo"].ToString());
            }
            con.Close();
        }
        public static bool MoneyTransferBeneficiaryAccIDVerify(int AccountID)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            int AccountIDCheck = 0;
            string Query = "Select AccountID from Account where AccountID = " + AccountID + ";";
            SqlCommand cmd = new SqlCommand(Query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                AccountIDCheck = int.Parse(reader["AccountID"].ToString());
            }
            con.Close();
            if (AccountIDCheck == AccountID)
            {
                return true;
            }
            return false;
        }
        public static bool MoneyTransferPassVerify(string pass)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string Query = "Select [Password] from [User] where UserID = " + User.UserID + ";";
            SqlCommand cmd = new SqlCommand(Query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            string passCheck = "";
            while (reader.Read())
            {
                passCheck = reader["Password"].ToString();
            }
            con.Close();
            if (pass == passCheck)
            {
                return true;
            }
            return false;
        }
        public static bool OldPasswordCheckSetting(string oldPass)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string Query = "Select [Password] from [User] where UserID = " + User.UserID + ";";
            SqlCommand cmd = new SqlCommand(Query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            string tempPass = "";
            while (reader.Read())
            {
                tempPass = reader["Password"].ToString();
            }
            con.Close();
            if (tempPass == oldPass)
            {
                return true;
            }
            return false;
        }
        public static void ChangeNewPasswordSetting(string newPass)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string Query = "Update [User] Set [Password] = '" + newPass + "' where UserID = " + User.UserID + ";";
            SqlCommand cmd = new SqlCommand(Query, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public static bool OldEmailCheckSetting(string oldEmail)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string Query = "Select Email from [User] where UserID = " + User.UserID + ";";
            SqlCommand cmd = new SqlCommand(Query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            string tempPass = "";
            while (reader.Read())
            {
                tempPass = reader["Email"].ToString();
            }
            con.Close();
            if (tempPass == oldEmail)
            {
                return true;
            }
            return false;
        }
        public static void ChangeNewEmailSetting(string newEmail)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string Query = "Update [User] Set Email = '" + newEmail + "' where UserID = " + User.UserID + ";";
            SqlCommand cmd = new SqlCommand(Query, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public static SqlDataReader Policies()
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string Query = "Select* from [Policy]";
            SqlCommand cmd = new SqlCommand(Query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            return reader;
        }
        public static SqlDataReader ChargesSchedule()
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string Query = "Select* from Charges";
            SqlCommand cmd = new SqlCommand(Query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            return reader;
        }
        public static void MoneyTransferBeneficiaryDetails(int beneficiaryAccID, ref int refAccountID, User usr1)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string Query = "Select AccountID, FullName, MobileNo from [User], Account where Account.UserID = [User].UserID AND Account.AccountID = " + beneficiaryAccID + ";";
            SqlCommand cmd = new SqlCommand(Query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                refAccountID = int.Parse(reader["AccountID"].ToString());
                usr1.FullName = reader["FullName"].ToString();
                usr1.MobileNo = long.Parse(reader["MobileNo"].ToString());
            }
            con.Close();
        }
        public static void ChargesDeductionFromTransferedAmount(Transaction beneficiary, BusinessLayer.Charges c1)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string GetChargesAmount = "Select* from Charges;";
            SqlCommand cmd = new SqlCommand(GetChargesAmount, con);
            SqlDataReader chargesReader = cmd.ExecuteReader();
            int previoustempChargeID = 0;
            int previousTempChargeIndex = 0;
            while (chargesReader.Read())
            {
                int tempchargeID = int.Parse(chargesReader["ChargeID"].ToString());
                int tempCharges = int.Parse(chargesReader["TransactionAmount"].ToString());
                int charges = int.Parse(chargesReader["ChargeAmount"].ToString());
                if (beneficiary.Amount <= tempCharges)
                {
                    Transaction t1 = new Transaction();
                    t1.CalculateChargedAmount(beneficiary, c1, previousTempChargeIndex, previoustempChargeID);
                    break;
                }
                previousTempChargeIndex = charges;
                previoustempChargeID = tempchargeID;
            }
            con.Close();
        }
        public static void InsertTransactionDetails(Transaction trasanction)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string query = "insert into [Transaction] (AccountID, BeneficiaryID, ChargeID, TransactionType, Amount, [TimeStamp]) Values(" + trasanction.AccountID + ", " + trasanction.BeneficiaryID + ", " + trasanction.ChargeID + ", '" + trasanction.TransactionType + "', " + trasanction.Amount + ", '" + trasanction.Time + "'); ";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public static void UpdatebalanceAfterTransaction(Transaction t1, string transactionType)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string query = null;
            if (transactionType == "Credited")
            {
                query = "update Account set Balance += " + t1.Amount + " where AccountID = " + t1.AccountID + ";";
            }
            else
            {
                query = "update Account set Balance -= " + t1.Amount + " where AccountID = " + t1.AccountID + ";";
            }
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public static SqlDataReader TransactionHistory()
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string Query = "Select BeneficiaryID, TimeStamp, Amount, TransactionType from [Transaction] where AccountID = " + Account.AccountID;
            SqlCommand cmd = new SqlCommand(Query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            return reader;
        }
        public static void CreditCardDetails(CreditCards c)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string query = "select CardNumber, ExpiryDate, CVV, CardName from CreditCard where AccountID = " + Account.AccountID + ";";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                c.CardName = reader["CardName"].ToString();
                c.CardID = long.Parse(reader["CardNumber"].ToString());
                c.CVV = int.Parse(reader["CVV"].ToString());
                c.ExpiryDate = reader["ExpiryDate"].ToString();
            }
            con.Close();
        }
        public static void UpdateActivationStatus()
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string query = "update CreditCard set ActivationStatus = 'Activated' Where AccountID = " + Account.AccountID + ";";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public static bool CheckActivationStatus()
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string query = "Select ActivationStatus from CreditCard where AccountID = " + Account.AccountID + ";";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            string activation = "NotActivated";
            while (reader.Read())
            {
                activation = reader["ActivationStatus"].ToString();
            }
            con.Close();
            if (activation == "NotActivated")
            {
                return true;
            }
            return false;
        }
        public static void UpdateCardPin(int pin)
        {
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string query = "update CreditCard set CardPin = " + pin + " where AccountID = " + Account.AccountID + ";";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
